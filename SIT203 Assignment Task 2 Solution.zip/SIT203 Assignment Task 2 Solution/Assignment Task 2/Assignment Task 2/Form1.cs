﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Assignment_Task_2
{
    public partial class Form1 : Form
    {
        // Log file name for append new log files
        private string logName = string.Format("LogFile-{0:yyyy-MM-dd_hh-mm-ss-tt}.html", DateTime.Now);

        // Crozzle file name for append new crozzle files
        private string CrozzleName = string.Format("Crozzle-{0:yyyy-MM-dd_hh-mm-ss-tt}.txt", DateTime.Now);

        static oldConfiguration oldCon = new oldConfiguration();

        static oldCrozzle oldCrz = new oldCrozzle();

        Crozzle crozzle = new Crozzle();

        Configuration configuration = new Configuration();

        List<CrozzleWords> easyAndMediumWds = new List<CrozzleWords> { };

        List<CrozzleWords> hardWds = new List<CrozzleWords> { };

        string oldCrozzleFile_name = oldCrz.getFileName();

        string oldConfigurationFile_name = oldCon.getFileName();

        string crozzle_FILE_NAME;

        string configuration_FILE_NAME;

        public Form1()
        {
            InitializeComponent();
        }

        private void crozzleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            crozzleWeb.DocumentText = "";
            crozzleFileErrorWeb.DocumentText = "";
            saveBtn.Enabled = false;
            configurationToolStripMenuItem.Enabled = true;
            OpenFileDialog opCrozzleFile = new OpenFileDialog();
            opCrozzleFile.InitialDirectory = "c://";

            // Filter all txt file when open file dialog
            opCrozzleFile.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";
            opCrozzleFile.RestoreDirectory = true;
            opCrozzleFile.FilterIndex = 1;

            if (opCrozzleFile.ShowDialog() == DialogResult.OK)
            {
                crozzle_FILE_NAME = opCrozzleFile.FileName;

            }
            try
            {
                crozzleFileErrorWeb.DocumentText = crozzle.ValidateFile(crozzle_FILE_NAME);
            }
            catch
            {
                MessageBox.Show("Please select a file.");
                configurationToolStripMenuItem.Enabled = false;
            }
        }

        private void configurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveBtn.Enabled = false;
            computeScoresToolStripMenuItem.Enabled = true;
            configurationFileErrorWeb.DocumentText = "";


            OpenFileDialog opConfigurationFile = new OpenFileDialog();
            opConfigurationFile.InitialDirectory = "c://";

            // Filter all txt file when open file dialog
            opConfigurationFile.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";
            opConfigurationFile.RestoreDirectory = true;
            opConfigurationFile.FilterIndex = 1;

            if (opConfigurationFile.ShowDialog() == DialogResult.OK)
            {
                configuration_FILE_NAME = opConfigurationFile.FileName;
            }
            try
            {
                configurationFileErrorWeb.DocumentText = configuration.ValidateFile(configuration_FILE_NAME);
            }
            catch
            {
                MessageBox.Show("Please select a file.");
                computeScoresToolStripMenuItem.Enabled = false;
            }
        }
        static IEnumerable<string> SortByLength(IEnumerable<string> words)
        {
            // Use LINQ to sort the array received and return a copy.
            var sorted = from word in words
                         orderby word.Length ascending
                         select word;
            return sorted;
        }

        private void scoreBtn_Click(object sender, EventArgs e)
        {


        }

        private void findBestCrozzleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveBtn.Enabled = false;
            try
            {
                int scores = 0;
                string[] in_letters = oldCrz.IntersectLetters(oldCrozzleFile_name);
                string[] no_letters = oldCrz.NonIntersectLetters(oldCrozzleFile_name);
                string[,] in_points = oldCon.IntersectLetterPoints();
                string[,] no_points = oldCon.NonIntersectLetterPoints();
                string message = null;
                int indexOfPoints = 1;
                int indexOfLetter = 0;
                string fileMessage;

                // If crozzle is invalid then the scores is zero
                if (oldCrz.ValidateCrozzle(oldCrozzleFile_name).Contains("Invalid"))
                {
                    scores = 0;
                    message = "<br/><br/>Crozzle is invalid<br/> Total score is " + scores + ". ";
                }

                // Else the scores will be computed according to the configuration file
                else
                {

                    // Compute each total words scores
                    scores = scores + oldCrz.getTotalLine() * oldCon.PointsPerWord();

                    // Compute each total intersecting letters scores
                    for (int i = 0; i < in_letters.Length; i++)
                        for (int j = 0; j < in_points.GetLength(0); j++)
                        {
                            if (in_letters[i] == in_points[j, indexOfLetter])
                            {
                                scores = scores + int.Parse(in_points[j, indexOfPoints]);

                            }
                        }

                    // Compute each total nonintersecting letters scores
                    for (int i = 0; i < no_letters.Length; i++)
                        for (int j = 0; j < no_points.GetLength(0); j++)
                        {
                            if (no_letters[i] == no_points[j, indexOfLetter])
                            {
                                scores = scores + int.Parse(no_points[j, indexOfPoints]);

                            }
                        }

                    message = message + "<br/><br/>Crozzle is valid<br/> Total score is " + scores + ". ";

                }

                // Write file name and scores to the web browser
                fileMessage = "<br>Crozzle file is:<br> " + oldCrozzleFile_name + "<br/><br/>Configuration file is:<br> " + oldConfigurationFile_name + "<br/>";

                message = @"<!DOCTYPE html><html><head> </head> <body>" + fileMessage + message + "</body></html>";

                textBox1.Text = scores.ToString();

                // Write log message to log file
                StreamWriter filewrite = File.AppendText(logName);

                // Record datetime when each time write infomation to log file
                string logInfo = string.Format("<br/><br/><br/>---------------------------{0:yyyy-MM-dd hh:mm:ss:tt}---------------------------", DateTime.Now);
                filewrite.Write(logInfo);
                filewrite.Write(message);
                filewrite.Close();
            }
            catch
            {
                MessageBox.Show("Please make sure you have selected both crozzle file and configuration file before computing scores!");
            }
        }

        private void computeScoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveBtn.Enabled = true;
           
            try
            {
                // crozzle read file and get content
                crozzle.ReadFile(crozzle_FILE_NAME);

                // configuration read file and get content
                configuration.ReadFile(configuration_FILE_NAME);
                FindBest BEST_CROZZLE = new FindBest(crozzle, configuration);

                // If crozzle is hard level thar excute Algorithm 1 
                if (crozzle.getLevel() == "HARD")
                {
                    //excute Algorithm 1 
                    crozzle = BEST_CROZZLE.Algorithm1(crozzle.getRows(), crozzle.getCols(), crozzle.wordlist2);
                    crozzle.changeToTable();

                    // Display crozzle
                 
                    crozzleWeb.DocumentText = BEST_CROZZLE.display(crozzle);
                    textBox1.Text = BEST_CROZZLE.CalculateScore(crozzle, configuration).ToString();
                    textBox2.Text = crozzle.getLevel();
                    hardWds = BEST_CROZZLE.crozzleList[BEST_CROZZLE.HighestIndex].choosedhardWord;

                }

                // Else if crozzle is easy and medium level that excute Algorithm 2 
                else
                {
                    // excute Algorithm 2
                    easyAndMediumWds = BEST_CROZZLE.Algorithm2(crozzle.getRows(), crozzle.getCols(), crozzle.getListByLength());

                    //Display crozzle
                    crozzleWeb.DocumentText = BEST_CROZZLE.displayEasyAndMedium(crozzle.getRows(), crozzle.getCols(), easyAndMediumWds);

                    textBox1.Text = BEST_CROZZLE.getEasyAndMediumScore(BEST_CROZZLE.Algorithm2(crozzle.getRows(), crozzle.getCols(), crozzle.getListByLength()), configuration).ToString();
                    textBox2.Text = crozzle.getLevel();
                }
            }
            catch
            {
                MessageBox.Show("Please select a CORRECT crozzle or configuration file！ ");
                saveBtn.Enabled = false;
            }


        }

        private void crozzleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            saveBtn.Enabled = false;
            textBox1.Text = "";
            textBox2.Text = "";
            crozzleWeb.DocumentText = "";
            crozzleFileErrorWeb.DocumentText = "";
            configurationToolStripMenuItem1.Enabled = true;
            try
            {
                oldCrozzleFile_name = oldCrz.ReadFile();
                if (oldCrozzleFile_name.Contains("Configuration"))
                {
                    MessageBox.Show("Please select a crozzle file (not a configuration file) !");
                }
                else
                {
                    textBox2.Text = oldCrz.getLevel();

                    // Crozzle display in the webBrowser
                    crozzleWeb.DocumentText = oldCrz.CrozzleDisplay(oldCrozzleFile_name);

                    // Errors detected in the file will be display in anonther web browser named 'crozzle file errors'
                    crozzleFileErrorWeb.DocumentText = "File: \n" + oldCrozzleFile_name + "<br/><br/>" + oldCrz.ValidateFile(oldCrozzleFile_name);

                    // Errors detected in the crozzle will be display in anonther web browser named 'crozzle validaion'
                    crozzleValidWeb.DocumentText = oldCrz.ValidateCrozzle(oldCrozzleFile_name);

                    // Write error message to log file
                    StreamWriter filewrite = File.CreateText(logName);

                    // Record datetime when each time write infomation to log file
                    string logInfo = string.Format("<br/><br/>---------------------------{0:yyyy-MM-dd hh:mm:ss:tt}---------------------------<br/>", DateTime.Now);
                    filewrite.Write(logInfo);
                    filewrite.Write(oldCrz.ValidateCrozzle(oldCrozzleFile_name));
                    filewrite.Write(logInfo);
                    filewrite.Write(oldCrz.ValidateFile(oldCrozzleFile_name));
                    filewrite.Close();
                }
            }
            catch
            {
                MessageBox.Show("Please select a correct crozzle file!");
            }
        }

        private void configurationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            saveBtn.Enabled = false;
            findBestCrozzleToolStripMenuItem.Enabled = true;
            configurationFileErrorWeb.DocumentText = "";


            try
            {
                oldConfigurationFile_name = oldCon.ReadFile();
                if (oldConfigurationFile_name.Contains("Crozzle"))
                {
                    MessageBox.Show("Please select a configuration file (not a crozzle file) !");
                }
                else
                {
                    configurationFileErrorWeb.DocumentText = "File: \n" + oldConfigurationFile_name + "<br/><br/>" + oldCon.ValidateFile(oldConfigurationFile_name);
                    // Write error message to log file
                    StreamWriter filewrite = File.AppendText(logName);

                    // Record datetime when each time write infomation to log file
                    string logInfo = string.Format("<br/><br/><br/>---------------------------{0:yyyy-MM-dd hh:mm:ss:tt}---------------------------", DateTime.Now);
                    filewrite.Write(logInfo);
                    filewrite.Write(oldCon.ValidateFile(oldConfigurationFile_name));
                    filewrite.Close();
                }
            }
            catch
            {
                MessageBox.Show("Please select a correct configuration file!");
            }
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            string CrozzleName = string.Format("Crozzle-{0:yyyy-MM-dd_hh-mm-ss-tt}.txt", DateTime.Now);

            List<String> copyHeaders = crozzle.getHeaders();

            StreamWriter filewrite = File.AppendText(crozzle.getLevel() + " - " + CrozzleName);
            if (crozzle.getLevel() == "EASY" || crozzle.getLevel() == "MEDIUM")
            {
                int countH = 0;
                int countV = 0;

                //Count the number of horizontal word and vertical words
                for (int i = 0; i < easyAndMediumWds.Count; i++)
                {
                    if (easyAndMediumWds[i].orientation == "HORIZONTAL")
                    {
                        countH++;
                    }
                    if (easyAndMediumWds[i].orientation == "VERTICAL")
                    {
                        countV++;
                    }
                }

                // Write crozzle headers to file
                for (int i = 0; i < copyHeaders.Count; i++)
                {
                    if (i == 0)
                    {
                        string[] line = copyHeaders[i].Split(',');
                        Console.WriteLine(line[0]);
                        line[line.Length - 1] = countV.ToString();
                        line[line.Length - 2] = countH.ToString();
                        Console.WriteLine(line[0]);
                        string header = null;
                        for (int j = 0; j < line.Length; j++)
                        {

                            if (j < line.Length - 1)
                            {
                                header = header + line[j] + ",";

                            }
                            else
                            {
                                header = header + line[j];
                            }
                        }

                        filewrite.WriteLine(header);
                    }
                    else
                    {
                        filewrite.WriteLine(copyHeaders[i]);
                    }

                }

                //Write horizontal and vertical words to file 
                for (int m = 0; m < easyAndMediumWds.Count; m++)
                {
                    if (easyAndMediumWds[m].orientation == "HORIZONTAL")
                    {
                        filewrite.WriteLine(easyAndMediumWds[m].orientation + "," + (easyAndMediumWds[m].x + 1) + ","
                             + (easyAndMediumWds[m].y - easyAndMediumWds[m].word.Length + 1) + "," + easyAndMediumWds[m].word);

                    }
                }
                for (int m = 0; m < easyAndMediumWds.Count; m++)
                {
                    if (easyAndMediumWds[m].orientation == "VERTICAL")
                    {
                        filewrite.WriteLine(easyAndMediumWds[m].orientation + "," + (easyAndMediumWds[m].x - easyAndMediumWds[m].word.Length + 1) + ","
                            + (easyAndMediumWds[m].y + 1) + "," + easyAndMediumWds[m].word);

                    }
                }

            }


            if (crozzle.getLevel() == "HARD")
            {
                int countH = 0;
                int countV = 0;

                //Count the number of horizontal word and vertical words
                for (int i = 0; i < hardWds.Count; i++)
                {
                    if (hardWds[i].orientation == "HORIZONTAL")
                    {
                        countH++;
                    }
                    if (hardWds[i].orientation == "VERTICAL")
                    {
                        countV++;
                    }
                }

                // Write crozzle headers to file
                for (int i = 0; i < copyHeaders.Count; i++)
                {
                    if (i == 0)
                    {
                        string[] line = copyHeaders[i].Split(',');
                        line[line.Length - 1] = countV.ToString();
                        line[line.Length - 2] = countH.ToString();
                        string header = null;
                        for (int j = 0; j < line.Length; j++)
                        {

                            if (j < line.Length - 1)
                            {
                                header = header + line[j] + ",";

                            }
                            else
                            {
                                header = header + line[j];
                            }
                        }

                        filewrite.WriteLine(header);
                    }
                    else
                    {
                        filewrite.WriteLine(copyHeaders[i]);
                    }

                }

                //Write horizontal and vertical words to file 
                for (int m = 0; m < hardWds.Count; m++)
                {
                    if (hardWds[m].orientation == "HORIZONTAL")
                    {
                        filewrite.WriteLine(hardWds[m].orientation + "," + hardWds[m].x + "," + hardWds[m].y + "," + hardWds[m].word);

                    }
                }
                for (int m = 0; m < hardWds.Count; m++)
                {
                    if (hardWds[m].orientation == "VERTICAL")
                    {
                        filewrite.WriteLine(hardWds[m].orientation + "," + hardWds[m].x + "," + hardWds[m].y + "," + hardWds[m].word);

                    }
                }
            }

            // Message Box prompt users that crozzle has write into file
            filewrite.Close();
            MessageBox.Show("Crozzle has saved and write to file:\n\n " + '"' + crozzle.getLevel() + " - " + CrozzleName + '"');


        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Click Create new crozzle to open relevant files and create a new, best crozzle.\n\nClick Open exist crozzle to open relevant files and display a crozzle.");
        }
    }
}
