﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Assignment_Task_2
{
    class Backup
    {
        string FILE_NAME;
        string[] wordlist;
        string level;
        private int rows;
        private int cols;
        private int amount;
        public string find;
        //public bool exist = false;

        public int desc = 0;
        public string ReadFile()
        {
            OpenFileDialog opCrozzleFile = new OpenFileDialog();
            opCrozzleFile.InitialDirectory = "c://";

            // Filter all txt file when open file dialog
            opCrozzleFile.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";
            opCrozzleFile.RestoreDirectory = true;
            opCrozzleFile.FilterIndex = 1;

            if (opCrozzleFile.ShowDialog() == DialogResult.OK)
            {
                FILE_NAME = opCrozzleFile.FileName;

            }

            return FILE_NAME;
        }
        private string getLevel()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(FILE_NAME);

            int line_counter = 0;
            int indexOfLevel = 0;
            string line;

            // Read file and get all words in the list from the file
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    string[] headers = line.Split(',');
                    level = headers[indexOfLevel];

                }
                line_counter++;
            }
            fileread.Close();
            return level;
        }
        private int getAmount()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(FILE_NAME);

            int line_counter = 0;
            int indexOfAmount = 1;
            string line;

            // Read file and get all words in the list from the file
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    string[] headers = line.Split(',');
                    amount = int.Parse(headers[indexOfAmount]);

                }
                line_counter++;
            }
            fileread.Close();
            return amount;
        }
        private int getRows()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(FILE_NAME);

            int line_counter = 0;
            int indexOfWidth = 2;
            string line;

            // Read file and get all words in the list from the file
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    string[] headers = line.Split(',');
                    rows = int.Parse(headers[indexOfWidth]);

                }
                line_counter++;
            }
            fileread.Close();
            return rows;
        }
        private int getCols()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(FILE_NAME);

            int line_counter = 0;
            int indexOfHeight = 3;
            string line;

            // Read file and get all words in the list from the file
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    string[] headers = line.Split(',');
                    cols = int.Parse(headers[indexOfHeight]);

                }
                line_counter++;
            }
            fileread.Close();
            return cols;
        }
        public string[] getWordList()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(FILE_NAME);

            int line_counter = 0;
            string line;

            // Read file and get all words in the list from the file
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter > 0)
                {
                    wordlist = line.Split(',');

                }
                line_counter++;
            }
            fileread.Close();
            return wordlist;
        }
        public string[,] BestEasyCrozzle()
        {
            List<string> words = new List<string>(getWordList());
            int row = getRows();
            int col = getCols();
            string[,] board = new string[row, col];
            string[] sorted = new string[words.Count];
            string startWord;
            int first = 0;
            int startX = 0;
            int startY = 0;
            int n = 0;

            List<WordArray> usedWords = new List<WordArray> { };
            List<Coordinates> availableChar = new List<Coordinates> { };
            List<choosedWords> availableWords = new List<choosedWords> { };
            List<string> copy = new List<string> { };

            foreach (var word in SortByLength(words))
            {
                sorted[n] = word;
                n++;
            }


            int startFirstRow = 0;
            int maxLength = sorted[sorted.Length - 1].Length;
            string[] maxLengthWords = new string[100];

            int count = 0;

            foreach (var word in words)
            {
                if (word.Length == maxLength)
                {
                    maxLengthWords[count] = word.ToString();
                    count++;
                }
            }

            startWord = maxLengthWords[first];
            words.Remove(words.Single(x => x == startWord));
            WordArray w = new WordArray();
            for (int k = 0; k < startWord.Length; k++)
            {
                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < col; j++)
                    {
                        board[startFirstRow, k] = startWord[k].ToString();

                        w.x = startX;
                        w.y = startY;
                        w.word = startWord;
                        w.vertical = false;
                        w.length = startWord.Length;

                    }

                }
            }
            usedWords.Add(w);



            for (int k = 0; k < startWord.Length; k++)
            {
                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < col; j++)
                    {
                        board[startFirstRow, k] = startWord[k].ToString();
                    }
                }

            }
            char common = startWord[0];
            Console.WriteLine(maxLength);
            //Console.WriteLine(common);

            string next = suggestWord(maxLength, common, words);
            Console.WriteLine(next);
            if (next != null) { desc = 0; find = null; }

            words.Remove(words.Single(x => x == next));
            WordArray w2 = new WordArray();
            for (int k = 0; k < next.Length; k++)
            {
                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < col; j++)
                    {
                        //if (board[k, startY] != null)
                        //{
                        //    intersectsLettersForEasy[k] = board[k, startY];
                        //    Console.WriteLine(intersectsLettersForEasy[k]);
                        //}
                        board[k, startY] = next[k].ToString();


                        w.x = startX;
                        w.y = startY;
                        w.word = next;
                        w.vertical = true;
                        w.length = next.Length;

                    }

                }
            }
            usedWords.Add(w);


            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if ((i == 2 || i == 4) && j == 0)
                    {
                        Coordinates c = new Coordinates();
                        c.letter = board[i, j];
                        c.x = i;
                        c.y = j;
                        c.vertical = false;
                        availableChar.Add(c);
                    }
                }
            }

            for (int i = 0; i < availableChar.Count; i++)
            {
                string get = (suggestWord(maxLength, availableChar.ElementAt(i).letter.ToCharArray()[first], words));
                choosedWords ch = new choosedWords();
                ch.x = availableChar.ElementAt(i).x;
                ch.y = availableChar.ElementAt(i).y;
                ch.vertical = false;
                ch.word = get;
                availableWords.Add(ch);
                Console.WriteLine(get);
                copy.Add(ch.word);
            }
            string thirdStep = null;


            foreach (var s in SortByLength(copy))
            {
                thirdStep = s;

            }
            // Console.WriteLine(thirdStep);
            for (int i = 0; i < availableWords.Count; i++)
            {
                if (availableWords.ElementAt(i).word != thirdStep)
                {
                    availableWords.Remove(availableWords.ElementAt(i));
                }
            }
            foreach (var s in availableWords)
            {
                WordArray w3 = new WordArray();
                w3.x = s.x;
                w3.y = s.y;
                w3.word = s.word;
                w3.vertical = false;
                usedWords.Add(w3);
                words.Remove(words.Single(x => x == w3.word));
                for (int i = 0; i < s.word.Length; i++)
                {
                    for (int j = 0; j < board.GetLength(0); j++)
                    {
                        for (int k = 0; k < board.GetLength(1); k++)
                        {
                            if (j == s.x && k >= s.y)
                            {
                                board[s.x, i] = s.word[i].ToString();
                            }
                        }
                    }
                }

            }




            List<placeMent> firstLetter = new List<placeMent> { };
            List<placeMent> nextLetter = new List<placeMent> { };
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (j >= 2 && i == 0)
                    {

                        if (board[i, j] != null)
                        {
                            placeMent p = new placeMent();
                            p.x = i;
                            p.y = j;
                            p.letter = board[i, j];
                            p.vertical = true;
                            firstLetter.Add(p);
                            //Console.WriteLine(p.letter);

                        }
                    }
                    if (j >= 2 && i > 0)
                    {

                        if (board[i, j] != null)
                        {
                            placeMent p = new placeMent();
                            p.x = i;
                            p.y = j;
                            p.letter = board[i, j];
                            p.vertical = true;
                            nextLetter.Add(p);
                            //Console.WriteLine(p.letter);
                        }
                    }
                }
            }

            bool exist = false;
            WordArray fourthStep = new WordArray();
            foreach (var s in words)
            {
                if (exist) break;
                for (int i = 0; i < nextLetter.Count; i++)
                {
                    if (exist) break;
                    if (s.Length > nextLetter.ElementAt(i).y)
                    {
                        if (s[first].ToString() == firstLetter.ElementAt(i).letter && s[nextLetter.ElementAt(i).y].ToString() == nextLetter.ElementAt(i).letter)
                        {
                            if (exist) break;
                            fourthStep.word = s;
                            fourthStep.x = firstLetter.ElementAt(i).x;
                            fourthStep.y = firstLetter.ElementAt(i).y;
                            fourthStep.vertical = true;
                            fourthStep.length = s.Length;
                            exist = true;
                        }
                    }
                }
            }
            usedWords.Add(fourthStep);
            words.Remove(words.Single(x => x == fourthStep.word));
            for (int i = 0; i < fourthStep.word.Length; i++)
            {
                for (int j = 0; j < board.GetLength(0); j++)
                {
                    for (int k = 0; k < board.GetLength(1); k++)
                    {
                        if (j >= fourthStep.x && k == fourthStep.y)
                        {
                            //Console.WriteLine(j+" "+fourthStep.y);
                            board[i, fourthStep.y] = fourthStep.word[i].ToString();
                        }
                    }
                }
            }
            WordArray fifthStep = new WordArray();
            fifthStep.x = fourthStep.x + 1 + fourthStep.length;
            fifthStep.y = fourthStep.y;

            copy.Clear();
            foreach (var s in SortByLength(words))
            {
                if (s.Length == maxLength - 1)
                {
                    copy.Add(s);

                }
            }
            fifthStep.word = copy.ElementAt(first);
            fifthStep.vertical = false;
            fifthStep.length = copy.ElementAt(first).Length;
            //Console.WriteLine(fifthStep.word);
            usedWords.Add(fifthStep);
            words.Remove(words.Single(x => x == fifthStep.word));

            int counter = 0;
            for (int j = 0; j < board.GetLength(0); j++)
            {
                for (int k = 0; k < board.GetLength(1); k++)
                {
                    if (j == fifthStep.x && k >= fifthStep.y && k < fifthStep.word.Length + fifthStep.y)
                    {
                        // Console.WriteLine(k);
                        board[fifthStep.x, k] = fifthStep.word[counter].ToString();
                        counter++;
                    }
                }
            }
            WordArray sixthStep = new WordArray();
            sixthStep.x = fifthStep.x;
            sixthStep.y = fifthStep.y;
            int commonLetter = 2;
            int restLength = col - fifthStep.x;

            foreach (var s in words)
            {
                if (s.Length == restLength && s[commonLetter] == fifthStep.word[first])
                {
                    sixthStep.word = s;
                    sixthStep.vertical = true;
                    sixthStep.length = s.Length;
                    Console.WriteLine(s);
                }
            }
            usedWords.Add(sixthStep);
            words.Remove(words.Single(x => x == sixthStep.word));
            counter = 0;
            for (int j = 0; j < board.GetLength(0); j++)
            {
                for (int k = 0; k < board.GetLength(1); k++)
                {
                    if (j >= sixthStep.x && k == sixthStep.y && j < sixthStep.word.Length + sixthStep.x)
                    {
                        // Console.WriteLine(k);
                        board[j, sixthStep.y] = sixthStep.word[counter].ToString();
                        counter++;
                    }
                }
            }




            WordArray seventhStep = new WordArray();
            seventhStep.word = suggestWord(maxLength - 1, sixthStep.word[first], words);
            Console.WriteLine(seventhStep.word);
            seventhStep.x = sixthStep.x + 2;
            seventhStep.y = sixthStep.y;
            seventhStep.vertical = false;
            counter = 0;
            for (int j = 0; j < board.GetLength(0); j++)
            {
                for (int k = 0; k < board.GetLength(1); k++)
                {
                    if (j == seventhStep.x && k >= seventhStep.y && k < seventhStep.word.Length + seventhStep.y)
                    {
                        // Console.WriteLine(k);
                        board[seventhStep.x, k] = seventhStep.word[counter].ToString();
                        counter++;
                    }
                }
            }


            firstLetter.Clear();
            nextLetter.Clear();
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (i == fifthStep.x && j > fifthStep.y)
                    {

                        if (board[i, j] != null)
                        {
                            placeMent p = new placeMent();
                            p.x = i;
                            p.y = j;
                            p.letter = board[i, j];
                            p.vertical = true;
                            firstLetter.Add(p);
                            Console.WriteLine(p.letter);

                        }
                    }
                    if (i == seventhStep.x && j > seventhStep.y)
                    {

                        if (board[i, j] != null)
                        {
                            placeMent p = new placeMent();
                            p.x = i;
                            p.y = j;
                            p.letter = board[i, j];
                            p.vertical = true;
                            nextLetter.Add(p);
                            Console.WriteLine(p.letter);
                        }
                    }
                }
            }

            exist = false;
            WordArray eighthStep = new WordArray();
            foreach (var s in words)
            {
                if (exist) break;
                for (int i = 0; i < nextLetter.Count; i++)
                {
                    if (exist) break;
                    if (s.Length == restLength)
                    {
                        if (s[first].ToString() == firstLetter.ElementAt(i).letter && s[commonLetter].ToString() == nextLetter.ElementAt(i).letter)
                        {
                            if (exist) break;
                            Console.WriteLine(s);
                            eighthStep.word = s;
                            eighthStep.x = firstLetter.ElementAt(i).x;
                            eighthStep.y = firstLetter.ElementAt(i).y;
                            eighthStep.vertical = true;
                            eighthStep.length = s.Length;
                            exist = true;
                        }
                    }
                }
            }
            usedWords.Add(eighthStep);
            words.Remove(words.Single(x => x == eighthStep.word));

            counter = 0;
            for (int j = 0; j < board.GetLength(0); j++)
            {
                for (int k = 0; k < board.GetLength(1); k++)
                {
                    if (j >= eighthStep.x && k == eighthStep.y && j < eighthStep.word.Length + eighthStep.x)
                    {
                        // Console.WriteLine(k);
                        board[j, eighthStep.y] = eighthStep.word[counter].ToString();
                        counter++;
                    }
                }
            }

















            return board;
        }
        private string suggestWord(int maxlength, char common, List<string> words)
        {
            find = null;
            desc++;
            int row = rows;
            int col = cols;
            string[] sorted = new string[words.Count];
            int n = 0;
            int firstLetter = 0;


            foreach (var word in SortByLength(words))
            {
                sorted[n] = word;
                // Console.WriteLine(word);
                n++;
            }
            for (int i = 0; i < sorted.Length; i++)
            {

                // Console.WriteLine(sorted[i].Length);
                //Console.WriteLine(maxlength);

                if (sorted[i].Length == maxlength - 2 && sorted[i][firstLetter] == common)
                {
                    find = sorted[i];

                }

            }

            if (find == null)
            {

                Console.WriteLine(desc);
                //  Console.WriteLine(common);
                find = suggestWord(maxlength - desc, common, words);
                return find;

            }
            else


                return find;

        }
        static IEnumerable<string> SortByLength(IEnumerable<string> words)
        {
            // Use LINQ to sort the array received and return a copy.
            var sorted = from word in words
                         orderby word.Length ascending
                         select word;
            return sorted;
        }
        public class WordArray
        {
            public int x;
            public int y;
            public string word;
            public bool vertical;
            public int length;
        }
        public class Coordinates
        {
            public int x;
            public int y;
            public string letter;
            public bool vertical;
        }
        public class choosedWords
        {
            public int x;
            public int y;
            public string word;
            public bool vertical;
        }
        public class placeMent
        {
            public int x;
            public int y;
            public string letter;
            public bool vertical;
        }
        public class WordsInList
        {
            //public int score;
            //public int length;
            //public string word;
        }
    }
}