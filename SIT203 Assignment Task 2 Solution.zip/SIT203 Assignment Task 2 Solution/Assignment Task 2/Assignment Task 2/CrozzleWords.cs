﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Task_2
{
    public class CrozzleWords
    {
        public int x;
        public int y;
        public string orientation;
        public string word;
        public CrozzleWords(string data)
        {
            this.word = data;
        }
        public CrozzleWords()
        {
           
        }
        public CrozzleWords(string orient, int x, int y, string word)
        {
            this.orientation = orient;
            this.x = x;
            this.y = y;
            this.word = word;
        }
    }
}
