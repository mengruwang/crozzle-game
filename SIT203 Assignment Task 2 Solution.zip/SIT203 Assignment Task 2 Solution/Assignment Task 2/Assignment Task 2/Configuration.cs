﻿using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using System.Text.RegularExpressions;

namespace Assignment_Task_2
{
    public class Configuration
    {

        // groupLimit in configuration file
        private int groupLimit;

        // Points Per word in configuration file
        private int pointsPerWord;

        // 26 long int array store 26 letters for intersects in configuration file
        private string[,] intersectsLetterPoints = new string[26,2];

        // 26 long int array store 26 letters for nonintersects in configuration file
        private string[,] nonIntersectsLetterPoints = new string[26, 2];



        /// <summary>
        /// get groupLimit in configuration file
        /// </summary>
        /// <returns>return int value with goupLimit number</returns>
        public int getGroupLimit()
        {
            return groupLimit;
        }

        /// <summary>
        /// get Points Per Word in configuration file
        /// </summary>
        /// <returns>return int value with Points Per Word</returns>
        public int getPointsPerWors()
        {
            return pointsPerWord;
        }

        /// <summary>
        /// get intersects point for each letter
        /// </summary>
        /// <returns>return a int array store with 26 points</returns>
        public string[,] getInterPoinsts()
        {
            return intersectsLetterPoints;
        }

        /// <summary>
        ///  get nonintersects point for each letter
        /// </summary>
        /// <returns>return a int array store with 26 points</returns>
        public string[,] getNonInterPoints()
        {
            return nonIntersectsLetterPoints;
        }
     
        /// <summary>
        /// Read configuration file
        /// </summary>
        /// <param name="file_name">read file with name of 'file_name' </param>
        public void ReadFile(string file_name)
        {

            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            string line;
            int indexOfPart = 1;
            int colOfPoints = 1;
            int colOfLetter=0;

            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    groupLimit = int.Parse(line.Split('=')[indexOfPart]);
                }
                if (line_counter == 1)
                {
                    pointsPerWord = int.Parse(line.Split('=')[indexOfPart]);
                }
                if (line_counter >= 2 && line_counter <= 27)
                {
                    string lettersAndPoints = line.Split(':')[indexOfPart];
                     intersectsLetterPoints [line_counter - 2,colOfLetter] = lettersAndPoints.Split('=')[colOfLetter];
                     intersectsLetterPoints[line_counter - 2, colOfPoints] = lettersAndPoints.Split('=')[colOfPoints];
                }
                if (line_counter > 27)
                {
                    string lettersAndPoints = line.Split(':')[indexOfPart];
                    nonIntersectsLetterPoints[line_counter - 28,colOfLetter] = lettersAndPoints.Split('=')[colOfLetter];
                    Console.WriteLine(line_counter - 28);
                    nonIntersectsLetterPoints[line_counter - 28, colOfPoints] = lettersAndPoints.Split('=')[colOfPoints];
                }
                line_counter++;
            }

        }


      
        /// <summary>
        /// The method is to validate configuration file that selected, validate the value format, spelling etc.
        /// </summary>
        /// 
        /// <param name="file_name">the para is file name and read data from the file</param>
        /// 
        /// <returns>return a string value which contains html elements and the error message can be used directly in the web browser</returns>
        public string ValidateFile(string file_name)
        {

            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int limit = 0;
            int limitNumber = 1;
            int wordsPoint = 0;
            int Point = 1;
            int intersect = 0;
            int letter = 0;
            int letterPoint = 1;
            int line_counter = 0;
            string line;
            string error_message = null;
            string errorHTML;
            int errorCounter = 0;

            // Using regular expression to check if words in the file have following illegal symbols
            string validCharacter = @"^([A-Z]+)$";
            string validDigit = @"^([0-9]+)$";

            // Read file and check whether values in each line is valid
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    // Check if the value's format or spelling is valid
                    try
                    {
                        string[] wordlist = line.Split('=');

                        if (wordlist[limit] == "GROUPSPERCROZZLELIMIT")
                        {
                            error_message = error_message + null;
                        }

                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " ( 'GROUPSPERCROZZLELIMIT' spelling or format error(s)).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";

                    }

                    // Check if the value's format or spelling is valid                    
                    try
                    {
                        string[] wordlist = line.Split('=');
                        Match m = Regex.Match(wordlist[limitNumber], validDigit);
                        if (m.Success)
                        {
                            error_message = error_message + null;
                        }

                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " (groups limit is not from '0' to '9' ).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";
                    }

                }

                // Check if the value's format or spelling is valid                    
                else if (line_counter == 1)
                {
                    try
                    {
                        string[] wordlist = line.Split('=');

                        if (wordlist[wordsPoint] == "POINTSPERWORD")
                        {
                            error_message = error_message + null;
                        }

                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " ( 'POINTSPERWORD' spelling or format error(s)).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";

                    }

                    // Check if  points is valid (greater or equals to zero)
                    try
                    {
                        string[] wordlist = line.Split('=');
                        Match m = Regex.Match(wordlist[Point], validDigit);
                        if (m.Success)
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " (point per words is not from '0' to '9' ).<br/>";
                        }
                    }

                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";
                    }

                }

                // Check if "INTERSECTING" or "NONINTERSECTING" is spelling correctly
                else if (line_counter >= 2)
                {
                    try
                    {
                        string[] wordlist = line.Split(':');
                        if (wordlist[intersect] == "INTERSECTING" || wordlist[intersect] == "NONINTERSECTING")
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + "( 'INTERSECTING' or 'NONINTERSECTING' spelling or format error(s)).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";

                    }

                    // Check if letters is from 'A' to 'Z'
                    try
                    {
                        string[] wordlist = line.Split(':');
                        string[] wordlist2 = wordlist[1].Split('=');

                        Match m = Regex.Match(wordlist2[letter], validCharacter);
                        Match m2 = Regex.Match(wordlist[letter], validCharacter);

                        if (m.Success || m2.Success)
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " ( intersecting or noninersecting letters is not from 'A' to 'Z' ).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";

                    }

                    // Check if letter is in correct format and points is valid (greater or equals to zero)
                    try
                    {
                        string[] wordlist = line.Split(':');
                        string[] wordlist2 = wordlist[1].Split('=');

                        Match m = Regex.Match(wordlist2[letterPoint], validDigit);
                        if (m.Success)
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + "( the number of points is not from '0' to '9' ).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";
                    }
                }
                line_counter++;
            }

            fileread.Close();

            // Check if 'error_message' is empty
            // If it is empty then the crozzle is valid, else is invalid and display the errorHTML
            if (error_message != "")
            {

                errorHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                </head><br/><strong> Configuration File Validation</strong><br/>
                                <body>" + error_message + "</body></html>";
            }

            else
            {
                errorHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                </head><br/><strong> Configuration File Validation</strong><br/>
                                <body> No error(s) detected in the Configuration file ! </body></html>";


            }
            return errorHTML;
        }

       
    }


}
