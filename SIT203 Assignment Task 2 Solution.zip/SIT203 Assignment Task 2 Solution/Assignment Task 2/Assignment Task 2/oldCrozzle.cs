﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Assignment_Task_2
{
    public class oldCrozzle
    {
        private string file_name;
        private int row, col;
        private string[,] horizontal, vertical;

        // Invalid crozzle message will be stored in this string value
        private string crozzleValidate;

        // Crozzle exception message will be stored in this string value
        private string crozzleException;

        // The value is represents the level of crozzle 
        private string level;

        private bool flag;

        // The value is represents the number of total horizontal words used in the crozzle
        private int totalHorizontal;

        // The value is represents the number of total vertical words used in the crozzle
        private int totalVertical;

        // The value is represents all words used in the crozzle
        private string[] crozzle_words;

        // The value is represents all words given from the crozzle file
        private string[] list_words;

        /// <summary>
        /// The method is to open file dialog and read crozzle file name which was selected
        /// </summary>
        /// 
        /// <returns>return a string value which is the name of selected crozzle file</returns>
        public string ReadFile()
        {
            OpenFileDialog opCrozzleFile = new OpenFileDialog();
            opCrozzleFile.InitialDirectory = "c://";

            // Filter all txt file when open file dialog
            opCrozzleFile.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";
            opCrozzleFile.RestoreDirectory = true;
            opCrozzleFile.FilterIndex = 1;

            if (opCrozzleFile.ShowDialog() == DialogResult.OK)
            {
                file_name = opCrozzleFile.FileName;

            }

            return file_name;
        }

        /// <summary>
        /// The method is just to get selected crozzle file name
        /// </summary>
        /// 
        /// <returns>return a string value which stores the file name</returns>
        public string getFileName()
        {
            return file_name;
        }

        /// <summary>
        /// This method is to store the crozzle in a html table and display in the webBrowser
        /// </summary>
        /// 
        /// <param name="file_name">the para is the file name which read data from the file</param>
        /// 
        /// <returns>return a string value which contains html element and crozzle table</returns>
        public string CrozzleDisplay(string file_name)
        {
            // Get the number of crozzle table rows
            int numberofrows = getRows();

            // Get the number of crozzle table cols
            int numberofcols = getCols();
            string displayHTML = @"<!DOCTYPE html><html><head><style>
                                   table  {
                                          width:360px;
                                          }
                                table, td {
                                          border: 1px solid black;
                                          border-collapse: collapse;
                                          }
                                   td {
                                    width:24px;height:24px;text-align: center;
                                      }
                                </style></head><body><table>";

            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;

            //to store each line of the file
            string line;

            //string array to store every letter of words
            string[,] crozzle = new string[numberofrows, numberofcols];
            int indexofdirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;

            try
            {
                while ((line = fileread.ReadLine()) != null)
                {

                    if (line_counter >= 2)
                    {
                        string[] wordlist = line.Split(',');

                        // Read horizontal words and store every letter in the string array
                        if (wordlist[indexofdirection] == "HORIZONTAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_col++;
                            }
                        }

                        // Read vertical words and store every letter in the string array
                        else if (wordlist[indexofdirection] == "VERTICAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_row++;

                            }
                        }
                    }
                    line_counter++;

                }

                fileread.Close();

                // Store the array into a html table
                for (int i = 0; i < getRows(); i++)
                {
                    displayHTML = displayHTML + "<tr>";

                    for (int j = 0; j < getCols(); j++)
                    {

                        if (crozzle[i, j] == null)
                        {
                            // If crozzle[i,j] is null the display a space
                            displayHTML = displayHTML + "<td>" + "&nbsp;" + "</td>";
                        }
                        else
                        {
                            // Else display the letter
                            displayHTML = displayHTML + "<td style='background:#CDCBCB '>" + crozzle[i, j] + "</td>";
                        }
                    }
                    displayHTML = displayHTML + "</tr>";
                }

                displayHTML = displayHTML + "</ table > " + " </ body ></ html > ";
            }

            // Catch the exception if the crozzle file too invalid to display
            catch
            {
                for (int i = 0; i < getRows(); i++)
                {
                    displayHTML = displayHTML + "<tr>";

                    for (int j = 0; j < getCols(); j++)
                    {
                        if (crozzle[i, j] == null)
                        {
                            displayHTML = displayHTML + "<td >" + "&nbsp;" + "</td>";
                        }
                        else
                        {
                            displayHTML = displayHTML + "<td style='background:#CDCBCB '>" + crozzle[i, j] + "</td>";
                        }
                    }
                    displayHTML = displayHTML + "</tr>";
                }

                displayHTML = displayHTML + "</ table > " + "Can not display crozzle compeletly. It is invalid. </ body ></ html > ";

            }
            return displayHTML;
        }

        /// <summary>
        /// The method is to get the number of total rows in the html table which crozzle UI stores in
        /// </summary>
        /// 
        /// <returns>return a int value represent the number of rows</returns>
        public int getRows()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            int rowofcrozzle = 2;
            string line;

            // Read how many rows in the table from the file
            while ((line = fileread.ReadLine()) != null)
            {
                try
                {
                    if (line_counter == 0)
                    {
                        string[] line1 = line.Split(',');
                        row = int.Parse(line1[rowofcrozzle]);

                    }
                }
                catch
                {
                    crozzleException = crozzleException + "File is invalid, can not read the number of rows.<br/>";
                }

                line_counter++;

            }
            fileread.Close();
            return row;
        }

        /// <summary>
        /// The method is to get the number of total columns in the html table which crozzle UI stores in
        /// </summary>
        /// 
        /// <returns>return a int value represent the number of columns</returns>
        public int getCols()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            int colofcrozzle = 3;
            string line;

            // Read how many rows in the table from the file
            while ((line = fileread.ReadLine()) != null)
            {
                try
                {
                    if (line_counter == 0)
                    {
                        string[] line1 = line.Split(',');
                        col = int.Parse(line1[colofcrozzle]);
                        // totalVertical = int.Parse(line1[indexOfVertical]);
                        // totalHorizontal = int.Parse(line1[indexOfHorizontal]);
                        //level = line1[indexOfLevel];
                    }
                }
                catch
                {
                    crozzleException = crozzleException + "File is invalid, can not read the number of columns.<br/>";

                }

                line_counter++;

            }
            fileread.Close();
            return col;
        }

        /// <summary>
        /// The method is to get the number of horizontal words in the crozzle
        /// </summary>
        /// 
        /// <returns>return a int value represents the amount of total horizontal words</returns>
        public int getTotalHorizontal()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            int indexOfHorizontal = 4;
            string line;

            // Read file and get the number of total horizontal words used in the crozzle
            while ((line = fileread.ReadLine()) != null)
            {
                try
                {
                    if (line_counter == 0)
                    {
                        string[] line1 = line.Split(',');
                        totalHorizontal = int.Parse(line1[indexOfHorizontal]);
                    }
                }
                catch
                {
                    crozzleException = crozzleException + "File is invalid, can not read the number of horizontal words.<br/>";

                }

                line_counter++;

            }
            fileread.Close();
            return totalHorizontal;

        }

        /// <summary>
        /// The method is to get the number of vertical words in the crozzle
        /// </summary>
        /// 
        /// <returns>return a int value represents the amount of total vertical words</returns>
        public int getTotalVertical()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            int indexOfVertical = 5;
            string line;

            // Read file and get the number of total vertical words used in the crozzle
            while ((line = fileread.ReadLine()) != null)
            {
                try
                {
                    if (line_counter == 0)
                    {
                        string[] line1 = line.Split(',');
                        totalVertical = int.Parse(line1[indexOfVertical]);
                    }
                }
                catch
                {
                    crozzleException = crozzleException + "File is invalid, can not read the number of vertical words.<br/>";
                }

                line_counter++;
            }

            fileread.Close();
            return totalVertical;

        }

        /// <summary>
        /// The method is to get the number of total words used in the crozzle
        /// </summary>
        /// 
        /// <returns>return a int value represents the amount of words used in the crozzle</returns>
        public int getTotalLine()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            string line;

            // Read file and get the number of total words used in the crozzle
            while ((line = fileread.ReadLine()) != null)
            {
                line_counter++;
            }

            fileread.Close();
            return line_counter - 2;

        }

        /// <summary>
        /// The method is to get all words used in the crozzle also from word list in the crozzle file
        /// </summary>
        /// 
        /// <returns>return a string array stores words in the crozzle</returns>
        public string[] getCrozzleWords()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            int counter = 0;
            int indexOfWords = 3;
            string line;
            string[] words = new string[getTotalLine()];

            // Read file and get all words used in the crozzle
            try
            {
                while ((line = fileread.ReadLine()) != null)
                {
                    if (line_counter >= 2)
                    {
                        string[] line1 = line.Split(',');
                        string word = line1[indexOfWords];
                        words[counter] = word;
                        counter++;

                    }
                    crozzle_words = words;
                    line_counter++;


                }
            }
            catch
            {
                crozzleException = crozzleException + "File is invalid, can not read the number of vertical words.<br/>";
            }
            fileread.Close();
            return crozzle_words;
        }

        /// <summary>
        /// The method is get all words that from the given word list in the crozzle file
        /// </summary>
        /// 
        /// <returns>return a string array stores all words in the list</returns>
        public string[] getListWords()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            string line;

            // Read file and get all words in the list from the file
            try
            {
                while ((line = fileread.ReadLine()) != null)
                {
                    if (line_counter == 1)
                    {
                        string[] line1 = line.Split(',');
                        list_words = line1;

                    }


                    line_counter++;
                }
            }
            catch
            {
                crozzleException = crozzleException + "File is invalid, can not read the number of vertical words.<br/>";
            }
            fileread.Close();
            return list_words;
        }

        /// <summary>
        /// The method is to get the level of selected crozzle
        /// </summary>
        /// 
        /// <returns>return a string which represents the level of the crozzle</returns>
        public string getLevel()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0, indexOfLevel = 0;
            string line;

            // Read file and get all words in the list from the file
            while ((line = fileread.ReadLine()) != null)
            {
                try
                {
                    if (line_counter == 0)
                    {
                        string[] line1 = line.Split(',');
                        level = line1[indexOfLevel];

                    }
                }
                catch
                {
                    crozzleException = crozzleException + "File is invalid, can not read the word list given in the file.<br/>";
                }

                line_counter++;

            }
            fileread.Close();
            return level;
        }

        /// <summary>
        /// The method is to get total horizontal words with its coordinates in the crozzle
        /// </summary>
        /// 
        /// <returns>return a 2D string array stores the words and their coordinates</returns>
        public string[,] AllHorizontal()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            int indexOfDirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;
            int startPosition;
            int endPosition;
            int indexOfLine = 0;
            int indexOfStart = 1;
            int indexOfEnd = 2;
            int indexOfHWord = 3;
            int h_counter = 0;
            string line;
            string[,] words = new string[getTotalHorizontal(), 4];
            horizontal = new string[getTotalHorizontal(), 4];

            // Read file and get all horizontal words used in the crozzle with their start coordinates and end coordinates
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter >= 2)
                {
                    try
                    {
                        string[] line1 = line.Split(',');

                        // Store each element into string array
                        if (line1[indexOfDirection] == "HORIZONTAL")
                        {
                            startPosition = int.Parse(line1[indexOfCol]);
                            endPosition = int.Parse(line1[indexOfCol]) + line1[indexOfWord].Length - 1;
                            //string direction = line1[indexOfDirection];
                            string row = line1[indexOfRow];
                            string word = line1[indexOfWord];
                            // words[h_counter, indexOfDirection] = direction;
                            words[h_counter, indexOfLine] = row;
                            words[h_counter, indexOfStart] = startPosition.ToString();
                            words[h_counter, indexOfEnd] = endPosition.ToString();
                            words[h_counter, indexOfHWord] = word;
                            h_counter++;
                        }
                    }
                    catch
                    {
                        crozzleException = crozzleException + "File is invalid, can not read the word list given in the file.<br/>";
                    }
                }

                horizontal = words;
                line_counter++;

            }

            fileread.Close();
            return horizontal;
        }

        /// <summary>
        /// The method is to get total vertical words with its coordinates in the crozzle
        /// </summary>
        /// 
        /// <returns>return a 2D string array stores the words and their coordinates</returns>
        public string[,] AllVertical()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;
            int indexOfDirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;
            int startPosition;
            int endPosition;
            int indexOfLine = 0;
            int indexOfStart = 1;
            int indexOfEnd = 2;
            int indexOfHWord = 3;
            int v_counter = 0;
            string line;
            string[,] words = new string[getTotalVertical(), 4];
            vertical = new string[getTotalVertical(), 4];

            // Read file and get all vertical words used in the crozzle with their start coordinates and end coordinates
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter >= 2)
                {
                    try
                    {
                        string[] line1 = line.Split(',');

                        // Store each element into string array
                        if (line1[indexOfDirection] == "VERTICAL")
                        {
                            startPosition = int.Parse(line1[indexOfCol]);
                            endPosition = int.Parse(line1[indexOfRow]) + line1[indexOfWord].Length - 1;
                            //string direction = line1[indexOfDirection];
                            string row = line1[indexOfRow];
                            string word = line1[indexOfWord];
                            //words[v_counter, indexOfDirection] = direction;
                            words[v_counter, indexOfLine] = row;
                            words[v_counter, indexOfStart] = startPosition.ToString();
                            words[v_counter, indexOfEnd] = endPosition.ToString();
                            words[v_counter, indexOfHWord] = word;
                            v_counter++;
                        }
                    }
                    catch
                    {
                        crozzleException = crozzleException + "File is invalid, can not read the word list given in the file.<br/>";
                    }
                }

                line_counter++;
                vertical = words;
            }

            fileread.Close();
            return vertical;
        }

        /// <summary>
        /// The method is to validate crozzle file that selected, validate the value format, spelling, range etc.
        /// </summary>
        /// 
        /// <param name="file_name">the para is file name and method read data from the file</param>
        /// 
        /// <returns>return a string value which contains html elements and the error message can be used directly in the web browser</returns>
        public string ValidateFile(string file_name)
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            string errorHTML;
            int crozzle_direction = 0;
            int crozzle_x = 1;
            int crozzle_y = 2;
            int level = 0;
            int indexOfWord = 3;
            int totalRows = 2;
            int totalCols = 3;
            int numberOfWords = 1;
            int numberOfHotizontal = 4;
            int numberOfVertical = 5;
            int line_counter = 0;
            int errorCounter = 0;
            string line;
            string error_message = null;

            // Using regular expression to check if words in the file have following illegal symbols
            string validCharacter = @"^([a-zA-Z]+)$";
            string validDigit = @"^([0-9]+)$";



            // Read file and check each line values if there is any voilations
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    // Check if there is six values in the crozzle file header
                    try
                    {
                        string[] wordlist = line.Split(',');
                        if (wordlist.Length == 6)
                        {
                            error_message = error_message + null;
                        }
                        else if (wordlist.Length < 6)
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the file header lost some values.<br/>";
                        }
                        else if (wordlist.Length > 6)
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", there is more than six values in the file header .<br/>";
                        }
                        for (int i = 0; i < wordlist.Length; i++)
                        {
                            if (wordlist[i] != "")
                            {
                                error_message = error_message + null;
                            }

                            else
                            {
                                errorCounter++;
                                error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", value(s) in the file header is not in correct format.<br/>";
                            }
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the file header lost some values.<br/>";
                    }

                    // Check if the level of crozzle is 'EASY', 'MEDIUM' or 'HARD'
                    try
                    {
                        string[] wordlist = line.Split(',');
                        if (wordlist[level] == "EASY" || wordlist[level] == "MEDIUM" || wordlist[level] == "HARD")
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;

                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + " (level format error(s))\n.<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;

                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + " (level format error(s))\n.<br/>";
                    }

                    // Check if the the number of all words is match 0-9 and in the valid range 10-1000
                    try
                    {
                        string[] wordlist = line.Split(',');
                        Match m = Regex.Match(wordlist[numberOfWords], validDigit);

                        if (m.Success && (int.Parse(wordlist[numberOfWords]) >= 10 && int.Parse(wordlist[numberOfWords]) <= 1000))
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of all words is " + wordlist[numberOfWords] + " in the crozzle is not within 10 to 1000.<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of rows in the crozzle is not within 10 to 1000.<br/>";

                    }

                    // Check if the the number of rows is match 0-9 and in the valid range 4-400
                    try
                    {
                        string[] wordlist = line.Split(',');
                        Match m = Regex.Match(wordlist[totalRows], validDigit);

                        if (m.Success && (int.Parse(wordlist[totalRows]) >= 4 && int.Parse(wordlist[totalRows]) <= 400))
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of rows in the crozzle is not within 4 to 400.<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of rows in the crozzle is not within 4 to 400.<br/>";

                    }

                    // Check if the total columns of crozzle is match 0-9 and in the valid range 8-800
                    try
                    {
                        string[] wordlist = line.Split(',');
                        Match m = Regex.Match(wordlist[totalCols], validDigit);

                        if (m.Success && (int.Parse(wordlist[totalCols]) >= 8 && int.Parse(wordlist[totalCols]) <= 800))
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of columns in the crozzle is not within 8 to 800.<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of columns in the crozzle is not within 8 to 800.<br/>";

                    }

                    // Check if the number of horizontal word is match 0-9 
                    try
                    {
                        string[] wordlist = line.Split(',');
                        Match m = Regex.Match(wordlist[numberOfHotizontal], validDigit);

                        if (m.Success && (int.Parse(wordlist[numberOfHotizontal]) >= 4 && int.Parse(wordlist[numberOfHotizontal]) <= 400))
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the number of horizontal words is not non-negative integer(s).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the number of horizontal words is not non-negative integer(s).<br/>";
                    }

                    // Check if the number of vertical word is match 0-9 
                    try
                    {
                        string[] wordlist = line.Split(',');
                        Match m = Regex.Match(wordlist[numberOfVertical], validDigit);

                        if (m.Success && (int.Parse(wordlist[numberOfVertical]) >= 4 && int.Parse(wordlist[numberOfVertical]) <= 400))
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the number of vertical words is not non-negative integer(s).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the number of vertical words is not non-negative integer(s).<br/>";
                    }
                }

                // Check if there is any voilations in line 2 (for file)
                else if (line_counter == 1)
                {
                    // Check if words contains illegal symbol or digit
                    try
                    {
                        string[] wordlist = line.Split(',');

                        for (int i = 0; i < wordlist.Length; i++)
                        {
                            Match m = Regex.Match(wordlist[i], validCharacter);
                            if (!m.Success)
                            {
                                errorCounter++;
                                error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the illegal symbol in the word " + " ' " + wordlist[i] + " ' " + " .<br/>";
                            }
                            else
                            {
                                error_message = error_message + null;
                            }
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the number of words in the list is not in the required range.<br/>";

                    }

                    // check if the word list has duplicated word(s)
                    try
                    {
                        string[] wordlist = line.Split(',');
                        for (int i = 1; i < wordlist.Length; i++)
                        {
                            flag = false;
                            for (int j = 0; j < i; j++)
                            {
                                if (wordlist[j] == wordlist[i])
                                {
                                    flag = true;
                                }
                            }
                            if (flag == false)
                            {
                                error_message = error_message + null;
                            }
                            else
                            {
                                errorCounter++;
                                error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", word " + wordlist[i] + " is duplicated.<br/>";
                            }
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + " words in the file violate rules.<br/>";
                    }

                }

                // Check if there is any voilations in line 3 (for file) and rest lines 
                else if (line_counter >= 2)
                {
                    // Check if the orientation is 'HORIZONTAL' or 'VERTICAL'
                    try
                    {
                        string[] wordlist = line.Split(',');

                        {
                            if ((wordlist[crozzle_direction] == "HORIZONTAL" || wordlist[crozzle_direction] == "VERTICAL"))
                            {
                                error_message = error_message + null;
                            }
                            else
                            {
                                errorCounter++;
                                error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", word orientation is illegal.<br/>";
                            }
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", word orientation is illegal.<br/>";
                    }

                    // Check if the position of each word is in a correct format
                    try
                    {
                        string[] wordlist = line.Split(',');

                        {
                            {
                                if ((int.Parse(wordlist[crozzle_x]) > 0 && int.Parse(wordlist[crozzle_y]) > 0))
                                {
                                    error_message = error_message + null;
                                }
                                else
                                {
                                    errorCounter++;
                                    error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the row(or column) location of the first letter in word " + wordlist[indexOfWord] + " is illegal (should be greater than zero)<br/>";
                                }
                            }
                            {
                                Match m = Regex.Match(wordlist[indexOfWord], validCharacter);
                                if (!m.Success)
                                {
                                    errorCounter++;
                                    error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the illegal symbol in the word " + wordlist[indexOfWord] + " .<br/>";
                                }
                                else
                                {
                                    error_message = error_message + null;
                                }
                            }
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the row(or column) location of the first letter of that word is illegal<br/>";
                    }

                }
                line_counter++;
            }

            fileread.Close();

            if (error_message != "")
            {

                errorHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                </head><strong> Crozzle File Validation</strong><br/>
                                <body>" + error_message + "</body></html>";
            }

            else
            {
                errorHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                </head><strong> Crozzle File Validation</strong><br/>
                                <body> No error(s) detected in the crozzle file ! </body></html>";


            }
            return errorHTML;
        }

        /// <summary>
        /// The method is to validate crozzle, different level crozzle has different as well as common constrains, the method is to 
        /// check if the crozzle violates those constrains
        /// </summary>
        /// 
        /// <param name="file_name">the para is file name and method read data from the file</param>
        /// 
        /// <returns>return a string value which contains html elements and the error message can be used directly in the web browser</returns>
        public string ValidateCrozzle(string file_name)
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int crz_errorCounter = 0;
            string error_message = null;
            string[,] allHorizontalWords = AllHorizontal();
            string[,] allVerticalWords = AllVertical();
            string[,] tempH = allHorizontalWords;
            string[,] tempV = allVerticalWords;
            int indexOfRow = 0;
            int indexOfStartCol = 1;
            int indexOfEndCol = 2;
            int indexOfCol = 1;
            int indexOfStartRow = 0;
            int indexOfEndRow = 2;
            int indexOfWord = 3;
           

            // Check if different level of crozzle violates the intersects constrains
            try
            {
                if (VerticalIntersection() != "")
                {

                    string[] line = VerticalIntersection().Split(';');
                    for (int i = 0; i < line.Length - 1; i++)
                    {
                        crz_errorCounter++;
                        error_message = error_message + crz_errorCounter + ". " + line[i];
                    }
                }

                if (HorizontalIntersection() != "")
                {
                    string[] line = HorizontalIntersection().Split(';');
                    for (int i = 0; i < line.Length - 1; i++)
                    {
                        crz_errorCounter++;
                        error_message = error_message + crz_errorCounter + ". " + line[i];
                    }
                }
            }
            catch
            {
                crz_errorCounter++;
                error_message = error_message + crz_errorCounter + ". " + "In valid crozzle, violate constrains.<br/>";
            }

            // Check if a horizontal word touches another horizontal word in easy level
            try
            {
                if (getLevel() == "EASY")
                {
                    for (int i = 1; i < allHorizontalWords.GetLength(0); i++)
                        for (int j = 0; j < i; j++)
                        {
                            if (allHorizontalWords[i, indexOfRow] == allHorizontalWords[j, indexOfRow] &&
                                ((int.Parse(allHorizontalWords[i, indexOfStartCol]) - 1) == int.Parse(allHorizontalWords[j, indexOfStartCol])
                                || int.Parse(allHorizontalWords[i, indexOfEndCol]) + 1 == int.Parse(allHorizontalWords[j, indexOfEndCol])))
                            {
                                crz_errorCounter++;
                                error_message = error_message + crz_errorCounter + ". A horizontal word " + allHorizontalWords[i, indexOfWord] + " touches another horizontal word " + allHorizontalWords[j, indexOfWord] + ".<br/>";
                            }
                            else if ((int.Parse(allHorizontalWords[i, indexOfRow]) == int.Parse(allHorizontalWords[j, indexOfRow]) + 1 || int.Parse(allHorizontalWords[i, indexOfRow]) == int.Parse(allHorizontalWords[j, indexOfRow]) - 1)
                                && ((int.Parse(allHorizontalWords[i, indexOfStartCol]) >= int.Parse(allHorizontalWords[j, indexOfStartCol]) && int.Parse(allHorizontalWords[i, indexOfStartCol]) <= int.Parse(allHorizontalWords[j, indexOfEndCol]) + 1)
                                || (int.Parse(allHorizontalWords[i, indexOfEndCol]) >= int.Parse(allHorizontalWords[j, indexOfStartCol]) - 1 && int.Parse(allHorizontalWords[i, indexOfEndCol]) <= int.Parse(allHorizontalWords[j, indexOfEndCol]))))
                            {
                                crz_errorCounter++;
                                error_message = error_message + crz_errorCounter + ". A horizontal word " + allHorizontalWords[i, indexOfWord] + " touches another horizontal word " + allHorizontalWords[j, indexOfWord] + ".<br/>";
                            }

                        }
                }
            }
            catch
            {
                crz_errorCounter++;
                error_message = error_message + crz_errorCounter + ". In valid crozzle, violate constrains.<br/> ";

            }

            // Check if a vertical word touches another vertical word in easy level
            try
            {
                if (getLevel() == "EASY")
                {
                    for (int i = 1; i < allVerticalWords.GetLength(0); i++)
                        for (int j = 0; j < i; j++)
                        {
                            if (allVerticalWords[i, indexOfCol] == allVerticalWords[j, indexOfCol] &&
                                ((int.Parse(allVerticalWords[i, indexOfStartRow]) - 1) == int.Parse(allVerticalWords[j, indexOfEndRow]) || int.Parse(allVerticalWords[i, indexOfEndRow]) + 1 == int.Parse(allVerticalWords[j, indexOfStartRow])))
                            {
                                crz_errorCounter++;
                                error_message = error_message + crz_errorCounter + ". A vertical word " + allVerticalWords[i, indexOfWord] + " touches another vertical word " + allVerticalWords[j, indexOfWord] + ".<br/>";
                            }
                            else if ((int.Parse(allVerticalWords[i, indexOfCol]) == int.Parse(allVerticalWords[j, indexOfCol]) + 1 || int.Parse(allVerticalWords[i, indexOfCol]) == int.Parse(allVerticalWords[j, indexOfCol]) - 1)
                                && ((int.Parse(allVerticalWords[i, indexOfStartRow]) >= int.Parse(allVerticalWords[j, indexOfStartRow]) && int.Parse(allVerticalWords[i, indexOfStartRow]) <= int.Parse(allVerticalWords[j, indexOfEndRow]) + 1)
                                || (int.Parse(allVerticalWords[i, indexOfEndRow]) >= int.Parse(allVerticalWords[j, indexOfStartRow]) - 1 && int.Parse(allVerticalWords[i, indexOfEndRow]) <= int.Parse(allVerticalWords[j, indexOfEndRow]))))
                            {
                                crz_errorCounter++;
                                error_message = error_message + crz_errorCounter + ". A vertical word " + allVerticalWords[i, indexOfWord] + " touches another vertical word " + allVerticalWords[j, indexOfWord] + ".<br/>";
                            }

                        }
                }
            }
            catch
            {
                crz_errorCounter++;
                error_message = error_message + crz_errorCounter + ". In valid crozzle, violate constrains.<br/> ";
            }

            // Check if the end or start of a horizontal word toches the end or start of a vertical word 
            try
            {
                for (int i = 0; i < allVerticalWords.GetLength(0); i++)
                    for (int j = 0; j < allHorizontalWords.GetLength(0); j++)
                    {
                        if ((int.Parse(allHorizontalWords[j, indexOfStartCol]) == int.Parse(allVerticalWords[i, indexOfCol]) && int.Parse(allHorizontalWords[j, indexOfRow]) == int.Parse(allVerticalWords[i, indexOfStartRow]) - 1)
                            || (int.Parse(allHorizontalWords[j, indexOfEndCol]) == int.Parse(allVerticalWords[i, indexOfCol]) && int.Parse(allHorizontalWords[j, indexOfRow]) == int.Parse(allVerticalWords[i, indexOfEndRow]) + 1)
                            || (int.Parse(allHorizontalWords[j, indexOfStartCol]) == int.Parse(allVerticalWords[i, indexOfCol]) && int.Parse(allHorizontalWords[j, indexOfRow]) == int.Parse(allVerticalWords[i, indexOfStartRow]) - 1)
                            || (int.Parse(allHorizontalWords[j, indexOfEndCol]) == int.Parse(allVerticalWords[i, indexOfCol]) && int.Parse(allHorizontalWords[j, indexOfRow]) == int.Parse(allVerticalWords[i, indexOfEndRow]) + 1))
                        {
                            crz_errorCounter++;
                            error_message = error_message + crz_errorCounter + ". The start or end of vertical word " + allVerticalWords[i, indexOfWord] + " touches the end or start of a horizontal word " + allHorizontalWords[j, indexOfWord] + ".<br/>";
                        }

                    }

            }
            catch
            {
                crz_errorCounter++;
                error_message = error_message + crz_errorCounter + ". In valid crozzle, violate constrains(may be a incorrect word in the crozzle).<br/> ";
            }

            try
            {
                for (int i = 0; i < allHorizontalWords.GetLength(0); i++)
                    for (int j = 0; j < allVerticalWords.GetLength(0); j++)
                    {
                        if ((int.Parse(allHorizontalWords[i, indexOfStartCol]) - 1 == int.Parse(allVerticalWords[j, indexOfCol]) && int.Parse(allHorizontalWords[i, indexOfRow]) == int.Parse(allVerticalWords[j, indexOfEndRow]))
                            || (int.Parse(allHorizontalWords[i, indexOfEndCol]) + 1 == int.Parse(allVerticalWords[j, indexOfCol]) && int.Parse(allHorizontalWords[i, indexOfRow]) == int.Parse(allVerticalWords[j, indexOfEndRow]))
                            || (int.Parse(allHorizontalWords[i, indexOfStartCol]) - 1 == int.Parse(allVerticalWords[j, indexOfCol]) && int.Parse(allHorizontalWords[i, indexOfRow]) == int.Parse(allVerticalWords[j, indexOfStartRow]))
                            || (int.Parse(allHorizontalWords[i, indexOfEndCol]) + 1 == int.Parse(allVerticalWords[j, indexOfCol]) && int.Parse(allHorizontalWords[i, indexOfRow]) == int.Parse(allVerticalWords[j, indexOfStartRow])))
                        {
                            crz_errorCounter++;
                            error_message = error_message + crz_errorCounter + ". The start or end of a horizontal word " + allHorizontalWords[i, indexOfWord] + " touches the end or start of a vertical word " + allVerticalWords[j, indexOfWord] + " which may cause " + allHorizontalWords[i, indexOfWord] + " is not a correct word.<br/>";
                        }

                    }

            }
            catch
            {
                crz_errorCounter++;
                error_message = error_message + crz_errorCounter + ". In valid crozzle, violate constrains(may be a incorrect word in the crozzle).<br/> ";
            }


            // Check if words in the crozzle match the words in the file list
            try
            {
                for (int j = 0; j < getCrozzleWords().Length; j++)
                {
                    flag = false;
                    for (int k = 0; k < getListWords().Length; k++)
                    {
                        if (crozzle_words[j] == list_words[k])
                        {
                            flag = true;
                        }
                    }

                    if (flag == true)
                    {
                        error_message = error_message + null;
                    }
                    else
                    {
                        crz_errorCounter++;
                        error_message = error_message + crz_errorCounter + ". " + crozzle_words[j] + " is not in the word list.<br/>";
                    }
                }
            }
            catch
            {
                crz_errorCounter++;
                error_message = error_message + crz_errorCounter + ". " + " Crozzle violate constains.<br/>";
            }

            // Check a whether a crozzle word is used more than once
            try
            {
                for (int j = 1; j < crozzle_words.Length; j++)
                {
                    flag = false;
                    for (int k = 0; k < j; k++)
                    {
                        if (crozzle_words[k] == crozzle_words[j])
                        {
                            flag = true;
                        }
                    }
                    if (flag == false)
                    {
                        error_message = error_message + null;
                    }
                    else
                    {
                        crz_errorCounter++;
                        error_message = error_message + crz_errorCounter + ". " + crozzle_words[j] + " was used more than once.<br/>";
                    }
                }

            }
            catch
            {
                error_message = error_message + crz_errorCounter + ". " + " Crozzle violate constains.<br/>";
            }

            // Check if crozzle groups limit violate the constraint
            if (getLevel() == "HARD")
            {
                try
                {
                    if (getWordGroups() == false)
                    {
                        error_message = error_message + null;
                    }
                    else
                    {
                        crz_errorCounter++;
                        error_message = error_message + crz_errorCounter + ". More than one word group in the crozzle.<br/>";
                    }

                }
                catch
                {
                    crz_errorCounter++;
                    error_message = error_message + crz_errorCounter + ". " + " crozzle violate word group limit constains.<br/>";
                }
            }



            fileread.Close();
            if (error_message != "")
            {
                crozzleValidate = @"<!DOCTYPE html><html>
                                <head>
                                </head>
                                <body><strong>Crozzle Validation</strong><br/>Invalid list:<br/>" + error_message + "</body ></html > ";
            }
            else
            {
                crozzleValidate = @"<!DOCTYPE html><html>
                                <head>
                                </head>
                                <body><strong>Crozzle Validation</strong><br/>" + "No error(s) detected in the crozzle.<br/>" + "</body ></html > ";
            }

            return crozzleValidate;
        }

        /// <summary>
        /// The method is to get all letters which are intersects from different words in the crozzle, this may also be usd in computing scores
        /// </summary>
        /// 
        /// <param name="file_name">the para is file name and method read data from the file</param>
        /// 
        /// <returns>return a string array stores all intersects letters in the crozzle</returns>
        public string[] IntersectLetters(string file_name)
        {

            // Get the number of crozzle table rows
            int numberofrows = row;

            // Get the number of crozzle table cols
            int numberofcols = col;


            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;

            // To store each line of the file
            string line;

            // A string array to store every letter of words
            string[,] crozzle = new string[numberofrows, numberofcols];
            string[] intersect = new string[100];

            // string[] nonintersect = new string[500];
            int indexOfDirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;
            int counter = 0;

            try
            {
                while ((line = fileread.ReadLine()) != null)
                {

                    if (line_counter >= 2)
                    {
                        string[] wordlist = line.Split(',');

                        // Read horizontal words and store every letter in the string array
                        if (wordlist[indexOfDirection] == "HORIZONTAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_col++;
                            }
                        }

                        // Read vertical words and store every letter in the string array
                        else if (wordlist[indexOfDirection] == "VERTICAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_row++;

                            }
                        }
                    }
                    line_counter++;
                }
                fileread.Close();

                // Pick up all the letters that are intersected
                for (int i = 0; i < crozzle.GetLength(0); i++)
                    for (int j = 0; j < crozzle.GetLength(1); j++)
                    {
                        if (crozzle[i, j] != null)
                        {

                            if (i == 0 && j == 0)
                            {
                                if (crozzle[i, j + 1] != null && crozzle[i + 1, j] != null)
                                {
                                    intersect[counter] = crozzle[i, j];
                                    counter++;

                                }


                            }
                            else if (i == 0 && j == crozzle.GetLength(1) - 1)
                            {
                                if (crozzle[i + 1, j] != null && crozzle[i, j - 1] != null)
                                {
                                    intersect[counter] = crozzle[i, j];
                                    counter++;

                                }

                            }
                            else if (i == crozzle.GetLength(0) - 1 && j == 0)
                            {
                                if (crozzle[i - 1, j] != null && crozzle[i, j + 1] != null)
                                {
                                    intersect[counter] = crozzle[i, j];
                                    counter++;

                                }

                            }
                            else if (i == crozzle.GetLength(0) - 1 && j == crozzle.GetLength(1) - 1)
                            {
                                if (crozzle[i - 1, j] != null && crozzle[i, j - 1] != null)
                                {
                                    intersect[counter] = crozzle[i, j];
                                    counter++;

                                }

                            }
                            // When it is in the first row, check if there is any intersecting letters
                            else if (i == 0 && j != crozzle.GetLength(1) - 1 && j != 0)
                            {
                                if (crozzle[i + 1, j] != null && (crozzle[i, j - 1] != null || crozzle[i, j + 1] != null))
                                {
                                    intersect[counter] = crozzle[i, j];
                                    counter++;
                                }
                            }


                            // When it is in the first column, check if there is any intersecting letters
                            else if (j == 0 && i != 0 && i != crozzle.GetLength(0) - 1)
                            {
                                if (crozzle[i, j + 1] != null && (crozzle[i - 1, j] != null || crozzle[i + 1, j] != null))
                                {
                                    intersect[counter] = crozzle[i, j];
                                    counter++;
                                }
                            }

                            // When it is in the last row, check if there is any intersecting letters
                            else if (i == crozzle.GetLength(0) - 1 && j != 0 && j != crozzle.GetLength(1) - 1)
                            {
                                if (crozzle[i - 1, j] != null && (crozzle[i, j - 1] != null || crozzle[i, j + 1] != null))
                                {
                                    intersect[counter] = crozzle[i, j];
                                    counter++;
                                }
                            }

                            // When it is in the last column, check if there is any intersecting letters
                            else if (j == crozzle.GetLength(1) - 1 && i != 0 && i != crozzle.GetLength(0) - 1)
                            {
                                if (crozzle[i, j - 1] != null && (crozzle[i - 1, j] != null || crozzle[i + 1, j] != null))
                                {
                                    intersect[counter] = crozzle[i, j];
                                    counter++;
                                }
                            }

                            // In other columns and rows, check if there is any intersecting letters
                            else if ((crozzle[i, j - 1] != null && (crozzle[i + 1, j] != null || crozzle[i - 1, j] != null))
                                || (crozzle[i, j + 1] != null && (crozzle[i + 1, j] != null || crozzle[i - 1, j] != null))
                                || (crozzle[i + 1, j] != null && (crozzle[i, j - 1] != null || crozzle[i, j + 1] != null))
                                || (crozzle[i - 1, j] != null && (crozzle[i, j - 1] != null || crozzle[i, j + 1] != null)))
                            {
                                intersect[counter] = crozzle[i, j];
                                counter++;
                            }
                        }
                    }
            }
            catch
            {
                crozzleException = crozzleException + "File is invalid, can not read the word list given in the file.<br/>";
            }

            return intersect;
        }

        /// <summary>
        /// The method is to get all letters which are not intersects from different words in the crozzle, this may also be usd in computing scores
        /// </summary>
        /// 
        /// <param name="file_name">the para is file name and method read data from the file</param>
        /// 
        /// <returns>return a string array stores all nonintersects letters in the crozzle</returns>
        public string[] NonIntersectLetters(string file_name)
        {

            // Get the number of crozzle table rows
            int numberofrows = row;

            // Get the number of crozzle table cols
            int numberofcols = col;


            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;

            // To store each line of the file
            string line;

            // A string array to store every letter of words
            string[,] crozzle = new string[numberofrows, numberofcols];
            string[] nonintersect = new string[500];
            int indexOfDirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;
            int counter = 0;
            try
            {
                while ((line = fileread.ReadLine()) != null)
                {
                    if (line_counter >= 2)
                    {
                        string[] wordlist = line.Split(',');

                        // Read horizontal words and store every letter in a string array
                        if (wordlist[indexOfDirection] == "HORIZONTAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_col++;
                            }
                        }

                        // Read vertical words and store every letter in a string array
                        else if (wordlist[indexOfDirection] == "VERTICAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_row++;

                            }
                        }
                    }

                    line_counter++;
                }



                fileread.Close();

                // Pick up all the letters that are nonintersected

                for (int i = 0; i < crozzle.GetLength(0); i++)
                    for (int j = 0; j < crozzle.GetLength(1); j++)
                    {
                        if (crozzle[i, j] != null)
                        {

                            if (i == 0 && j == 0)
                            {
                                if ((crozzle[i, j + 1] != null && crozzle[i + 1, j] == null) || (crozzle[i, j + 1] == null && crozzle[i + 1, j] != null))
                                {
                                    nonintersect[counter] = crozzle[i, j];
                                    counter++;

                                }
                            }

                            else if (i == 0 && j == crozzle.GetLength(1) - 1)
                            {
                                if ((crozzle[i + 1, j] != null && crozzle[i, j - 1] == null) || (crozzle[i, j - 1] != null && crozzle[i + 1, j] == null))
                                {
                                    nonintersect[counter] = crozzle[i, j];
                                    counter++;

                                }

                            }
                            else if (i == crozzle.GetLength(0) - 1 && j == 0)
                            {
                                if ((crozzle[i - 1, j] != null && crozzle[i, j + 1] == null) || (crozzle[i - 1, j] == null && crozzle[i, j + 1] != null))
                                {
                                    nonintersect[counter] = crozzle[i, j];
                                    counter++;

                                }

                            }
                            else if (i == crozzle.GetLength(0) - 1 && j == crozzle.GetLength(1) - 1)
                            {
                                if ((crozzle[i - 1, j] != null && crozzle[i, j - 1] == null) || (crozzle[i - 1, j] == null && crozzle[i, j - 1] != null))
                                {
                                    nonintersect[counter] = crozzle[i, j];
                                    counter++;

                                }

                            }
                            // When it is in the first row, check if there is any nonintersecting letters
                            else if (i == 0 && j != crozzle.GetLength(1) - 1 && j != 0)

                            {
                                if (crozzle[i + 1, j] == null && (crozzle[i, j - 1] != null || crozzle[i, j + 1] != null) || (crozzle[i + 1, j] != null && (crozzle[i, j - 1] == null && crozzle[i, j + 1] == null)))
                                {
                                    nonintersect[counter] = crozzle[i, j];
                                    counter++;
                                }

                            }

                            // When it is in the first column, check if there is any nonintersecting letters
                            else if (j == 0 && i != 0 && i != crozzle.GetLength(0) - 1)
                            {
                                if (crozzle[i, j + 1] == null && (crozzle[i - 1, j] != null || crozzle[i + 1, j] != null) || (crozzle[i, j + 1] != null && (crozzle[i - 1, j] == null && crozzle[i + 1, j] == null)))
                                {
                                    nonintersect[counter] = crozzle[i, j];
                                    counter++;
                                }
                            }


                            // When it is in the last row, check if there is any nonintersecting letters
                            else if (i == crozzle.GetLength(0) - 1 && j != 0 && j != crozzle.GetLength(1) - 1)
                            {
                                if (crozzle[i - 1, j] == null && (crozzle[i, j - 1] != null || crozzle[i, j + 1] != null) || (crozzle[i - 1, j] != null && (crozzle[i, j - 1] == null && crozzle[i, j + 1] == null)))
                                {
                                    nonintersect[counter] = crozzle[i, j];
                                    counter++;
                                }
                            }

                            // When it is in the last column, check if there is any nonintersecting letters
                            else if (j == crozzle.GetLength(1) - 1 && i != 0 && i != crozzle.GetLength(0) - 1)
                            {
                                if (crozzle[i, j - 1] == null && (crozzle[i - 1, j] != null || crozzle[i + 1, j] != null) || (crozzle[i, j - 1] != null && (crozzle[i - 1, j] == null && crozzle[i + 1, j] == null)))
                                {
                                    nonintersect[counter] = crozzle[i, j];
                                    counter++;
                                }
                            }


                            // In other columns and rows, check if there is any nonintersecting letters
                            else if ((crozzle[i - 1, j] != null || crozzle[i + 1, j] != null) && (crozzle[i, j - 1] == null && crozzle[i, j + 1] == null)
                                || (crozzle[i - 1, j] == null && crozzle[i + 1, j] == null) && (crozzle[i, j - 1] != null || crozzle[i, j + 1] != null))
                            {
                                nonintersect[counter] = crozzle[i, j];
                                counter++;
                            }
                        }
                    }

            }

            catch
            {
                crozzleException = crozzleException + "File is invalid, can not read the word list given in the file.<br/>";

            }

            return nonintersect;
        }

        /// <summary>
        /// The method is to check if each vertical words intersects other horizontal words and if they voilate the constrains
        /// </summary>
        /// 
        /// <returns>return a string store a error message if there is any vertical word voilates the constrains</returns>
        public string VerticalIntersection()
        {
            // Get the number of crozzle table rows
            int numberofrows = row;

            // Get the number of crozzle table cols
            int numberofcols = col;

            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int indexOfDirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;
            string line;
            int line_counter = 0;
            string[,] crozzle = tempV_Array();
            string error_message = null;
            int v_counter = 0;

            // To check how many words a vertical words intersects and judge if the word voilates the constrains
            try
            {
                while ((line = fileread.ReadLine()) != null)
                {
                    if (line_counter >= 2)
                    {
                        string[] wordlist = line.Split(',');

                        if (wordlist[indexOfDirection] == "HORIZONTAL")
                        {
                            v_counter = 0;
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;

                            // To check how many words a vertical words intersects
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                if (crozzle[insert_row, insert_col] != null)
                                {
                                    v_counter++;
                                }
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_col++;
                            }

                            // Check if the word voilates the the different level constrains
                            if (getLevel() == "EASY")
                            {
                                if (v_counter >= 1 && v_counter <= 2)
                                {
                                    error_message = error_message + null;

                                }
                                else if (v_counter < 1)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects less than one words.<br/>;";
                                }
                                else if (v_counter > 2)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects more than two words.<br/>;";
                                }
                            }

                            else if (getLevel() == "MEDIUM")
                            {
                                if (v_counter >= 1 && v_counter <= 3)
                                {
                                    error_message = error_message + null;

                                }
                                else if (v_counter < 1)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects less than one words.<br/>;";
                                }
                                else if (v_counter > 3)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects more than three words.<br/>;";
                                }
                            }

                            else if (getLevel() == "HARD")
                            {
                                if (v_counter >= 1)
                                {
                                    error_message = error_message + null;

                                }
                                else if (v_counter < 1)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects less than one words.<br/>;";
                                }

                            }
                            else
                            {
                                error_message = error_message + " Crozzle level is incorrect, so can not check how many word(s) the current horizontal word intersects.<br/>;";
                            }
                        }
                    }
                    line_counter++;
                }
                fileread.Close();

            }
            catch
            {
                error_message = error_message + "Invalid crozzle. A horizontal word position(read from file) is out of index range.<br/>;";

            }

            return error_message;
        }

        /// <summary>
        /// The method is to check if each horizontal words intersects other vertical words and if they voilate the constrains
        /// </summary>
        /// 
        /// <returns>return a string store a error message if there is any horizontal word voilates the constrains</returns>
        public string HorizontalIntersection()
        {
            // Get the number of crozzle table rows
            int numberofrows = row;

            // Get the number of crozzle table columns
            int numberofcols = col;

            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int indexofdirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;
            string line;
            int line_counter = 0;
            string[,] crozzle = new string[numberofrows, numberofcols];
            string error_message = null;
            int h_counter = 0;


            // To check how many words a vertical words intersects and judge if the word voilates the constrains
            try
            {
                while ((line = fileread.ReadLine()) != null)
                {
                    if (line_counter >= 2)
                    {
                        string[] wordlist = line.Split(',');

                        // Read horizontal words and store every letter in a string array
                        if (wordlist[indexofdirection] == "HORIZONTAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_col++;
                            }
                        }

                        // Read vertical words and store every letter in a string array
                        else if (wordlist[indexofdirection] == "VERTICAL")
                        {
                            h_counter = 0;
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;

                            // To check how many words a vertical words intersects
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                if (crozzle[insert_row, insert_col] != null)
                                {
                                    h_counter++;
                                }
                                crozzle[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_row++;
                            }

                            // Check if the word voilates the the different level constrains
                            if (getLevel() == "EASY")
                            {
                                if (h_counter >= 1 && h_counter <= 2)
                                {
                                    error_message = error_message + null;

                                }
                                else if (h_counter < 1)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects less than one words.<br/>;";
                                }
                                else if (h_counter > 2)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects more than two words.<br/>;";
                                }
                            }
                            else if (getLevel() == "MEDIUM")
                            {
                                if (h_counter >= 1 && h_counter <= 3)
                                {
                                    error_message = error_message + null;

                                }
                                else if (h_counter < 1)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects less than one words.<br/>;";
                                }
                                else if (h_counter > 3)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects more than three words.<br/>;";
                                }
                            }
                            else if (getLevel() == "HARD")
                            {
                                if (h_counter >= 1)
                                {
                                    error_message = error_message + null;

                                }
                                else if (h_counter < 1)
                                {
                                    error_message = error_message + wordlist[indexOfWord] + " intersects less than one words.<br/>;";
                                }

                            }
                            else
                            {
                                error_message = error_message + " Crozzle level is incorrect, so can not check how many word(s) the current vertical word intersects.<br/>;";
                            }
                        }
                    }
                    line_counter++;
                }
                fileread.Close();

            }
            catch
            {
                error_message = error_message + "Invalid crozzle. A vertical word position(read from file) is out of index range.<br/>;";

            }
            return error_message;
        }

        /// <summary>
        /// The method is to store only vertical words in the table
        /// </summary>
        /// 
        /// <returns>return a 2D stirng array stores vertical words in the table</returns>
        public string[,] tempV_Array()
        {
            // Get the number of crozzle table rows
            int numberofrows = row;

            // Get the number of crozzle table cols
            int numberofcols = col;

            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int indexofdirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;
            string line;
            int line_counter = 0;
            string[,] temp = new string[numberofrows, numberofcols];

            // Store only vertival words into talble
            try
            {
                while ((line = fileread.ReadLine()) != null)
                {

                    if (line_counter >= 2)
                    {
                        string[] wordlist = line.Split(',');

                        if (wordlist[indexofdirection] == "VERTICAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                temp[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_row++;
                            }
                        }
                    }

                    line_counter++;
                }

                fileread.Close();
            }
            catch
            {
                crozzleException = crozzleException + "File is invalid, can not read the word list given in the file.<br/>";
            }
            return temp;
        }

        /// <summary>
        /// The method is to store only horizontal words in the table
        /// </summary>
        /// 
        /// <returns>return a 2D stirng array stores horizontal words in the table</returns>
        public string[,] tempH_Array()
        {
            // Get the number of crozzle table rows
            int numberofrows = row;

            // Get the number of crozzle table cols
            int numberofcols = col;

            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int indexofdirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;
            string line;
            int line_counter = 0;
            string[,] temp = new string[numberofrows, numberofcols];

            // Store only horizontal words into talble
            try
            {
                while ((line = fileread.ReadLine()) != null)
                {

                    if (line_counter >= 2)
                    {
                        string[] wordlist = line.Split(',');

                        if (wordlist[indexofdirection] == "HORIZONTAL")
                        {

                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                temp[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_col++;
                            }
                        }
                    }

                    line_counter++;
                }

                fileread.Close();
            }
            catch
            {
                crozzleException = crozzleException + "File is invalid, can not read the word list given in the file.<br/>";
            }
            return temp;
        }

        /// <summary>
        /// The method is store crozzle into a table
        /// </summary>
        /// 
        /// <returns>return a string array which stores crozzle in a table</returns>
        public string[,] CrozzleTable()
        {
            // String array to store every letter of words
            string[,] crozzleTable = new string[row, col];
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int line_counter = 0;

            //to store each line of the file
            string line;
            int indexofdirection = 0;
            int indexOfRow = 1;
            int indexOfCol = 2;
            int indexOfWord = 3;

            try
            {
                while ((line = fileread.ReadLine()) != null)
                {

                    if (line_counter >= 2)
                    {
                        string[] wordlist = line.Split(',');

                        // Read horizontal words and store every letter in the string array
                        if (wordlist[indexofdirection] == "HORIZONTAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzleTable[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_col++;
                            }
                        }

                        // Read vertical words and store every letter in the string array
                        else if (wordlist[indexofdirection] == "VERTICAL")
                        {
                            int insert_row = int.Parse(wordlist[indexOfRow]) - 1;
                            int insert_col = int.Parse(wordlist[indexOfCol]) - 1;
                            for (int i = 0; i < wordlist[indexOfWord].Length; i++)
                            {
                                crozzleTable[insert_row, insert_col] = (wordlist[indexOfWord].ToCharArray()[i]).ToString();
                                insert_row++;

                            }
                        }
                    }
                    line_counter++;

                }
            }
            catch
            {
                crozzleException = crozzleException + "File is invalid, can not read the word list given in the file.<br/>";
            }

            fileread.Close();
            return crozzleTable;
        }

        /// <summary>
        /// The method is to check if there is only one word group in the crozzle
        /// </summary>
        /// <returns>return a bool value, if there is only one group in the crozzle,return false, else return true</returns>
        public bool getWordGroups()
        {
            bool oneGroup = false;
            if (HorizontalIntersection().Contains("less than one word") || VerticalIntersection().Contains("less than one word"))
            {
                oneGroup = true;
            }
            return oneGroup;
        }

        /// <summary>
        /// The method is to get error message when met exceptions
        /// </summary>
        /// <returns>a string value represents exception message</returns>
        public string ExceptionMessage()
        {
            crozzleException = @" <!DOCTYPE html><html><head></head><body> " + crozzleException + " </body></html>";
            return crozzleException;

        }

    }
}
