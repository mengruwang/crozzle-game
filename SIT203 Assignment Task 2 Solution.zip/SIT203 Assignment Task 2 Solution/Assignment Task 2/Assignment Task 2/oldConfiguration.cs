﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Assignment_Task_2
{
    public class oldConfiguration
    {
        private string configurationFile_name;
        private int groupsLimit;
        private int pointsPerWord;
        private string configurationException;

        /// <summary>
        /// The method is to open file dialog and read configuration file name which was selected
        /// </summary>
        /// 
        /// <returns>return a string value which is the name of selected configuration file</returns>
        public string ReadFile()
        {
            OpenFileDialog opConfigurationFile = new OpenFileDialog();
            opConfigurationFile.InitialDirectory = "c://";

            // Filter all txt file when open file dialog
            opConfigurationFile.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";
            opConfigurationFile.RestoreDirectory = true;
            opConfigurationFile.FilterIndex = 1;

            if (opConfigurationFile.ShowDialog() == DialogResult.OK)
            {
                configurationFile_name = opConfigurationFile.FileName;
            }

            return configurationFile_name;
        }

        /// <summary>
        /// The method is just to get selected configuration file name
        /// </summary>
        /// 
        /// <returns>return a string value which stores the file name</returns>
        public string getFileName()
        {
            return configurationFile_name;
        }


        /// <summary>
        /// The method is to validate configuration file that selected, validate the value format, spelling etc.
        /// </summary>
        /// 
        /// <param name="file_name">the para is file name and read data from the file</param>
        /// 
        /// <returns>return a string value which contains html elements and the error message can be used directly in the web browser</returns>
        public string ValidateFile(string file_name)
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            int limit = 0;
            int limitNumber = 1;
            int wordsPoint = 0;
            int Point = 1;
            int intersect = 0;
            int letter = 0;
            int letterPoint = 1;
            int line_counter = 0;
            string line;
            string error_message = null;
            string errorHTML;
            int errorCounter = 0;

            // Using regular expression to check if words in the file have following illegal symbols
            string validCharacter = @"^([A-Z]+)$";
            string validDigit = @"^([0-9]+)$";

            // Read file and check whether values in each line is valid
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    // Check if the value's format or spelling is valid
                    try
                    {
                        string[] wordlist = line.Split('=');

                        if (wordlist[limit] == "GROUPSPERCROZZLELIMIT")
                        {
                            error_message = error_message + null;
                        }

                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " ( 'GROUPSPERCROZZLELIMIT' spelling or format error(s)).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";

                    }

                    // Check if the value's format or spelling is valid                    
                    try
                    {
                        string[] wordlist = line.Split('=');
                        Match m = Regex.Match(wordlist[limitNumber], validDigit);
                        if (m.Success)
                        {
                            error_message = error_message + null;
                        }

                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " (groups limit is not from '0' to '9' ).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";
                    }

                }

                // Check if the value's format or spelling is valid                    
                else if (line_counter == 1)
                {
                    try
                    {
                        string[] wordlist = line.Split('=');

                        if (wordlist[wordsPoint] == "POINTSPERWORD")
                        {
                            error_message = error_message + null;
                        }

                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " ( 'POINTSPERWORD' spelling or format error(s)).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";

                    }

                    // Check if  points is valid (greater or equals to zero)
                    try
                    {
                        string[] wordlist = line.Split('=');
                        Match m = Regex.Match(wordlist[Point], validDigit);
                        if (m.Success)
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " (point per words is not from '0' to '9' ).<br/>";
                        }
                    }

                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";
                    }

                }

                // Check if "INTERSECTING" or "NONINTERSECTING" is spelling correctly
                else if (line_counter >= 2)
                {
                    try
                    {
                        string[] wordlist = line.Split(':');
                        if (wordlist[intersect] == "INTERSECTING" || wordlist[intersect] == "NONINTERSECTING")
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + "( 'INTERSECTING' or 'NONINTERSECTING' spelling or format error(s)).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";

                    }

                    // Check if letters is from 'A' to 'Z'
                    try
                    {
                        string[] wordlist = line.Split(':');
                        string[] wordlist2 = wordlist[1].Split('=');

                        Match m = Regex.Match(wordlist2[letter], validCharacter);
                        Match m2 = Regex.Match(wordlist[letter], validCharacter);

                        if (m.Success || m2.Success)
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + " ( intersecting or noninersecting letters is not from 'A' to 'Z' ).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";

                    }

                    // Check if letter is in correct format and points is valid (greater or equals to zero)
                    try
                    {
                        string[] wordlist = line.Split(':');
                        string[] wordlist2 = wordlist[1].Split('=');

                        Match m = Regex.Match(wordlist2[letterPoint], validDigit);
                        if (m.Success)
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + "( the number of points is not from '0' to '9' ).<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Configuration file error(s) detected in the line " + (line_counter + 1) + ", value(s) format is invalid (no ':' or '=' symbol).<br/>";
                    }
                }
                line_counter++;
            }

            fileread.Close();

            // Check if 'error_message' is empty
            // If it is empty then the crozzle is valid, else is invalid and display the errorHTML
            if (error_message != "")
            {

                errorHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                </head><br/><strong> Configuration File Validation</strong><br/>
                                <body>" + error_message + "</body></html>";
            }

            else
            {
                errorHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                </head><br/><strong> Configuration File Validation</strong><br/>
                                <body> No error(s) detected in the Configuration file ! </body></html>";


            }
            return errorHTML;
        }

        /// <summary>
        /// The method is to get the limit of word groups in the file
        /// </summary>
        /// 
        /// <returns>return a int value which represents the limit numnber</returns>
        public int GroupsLimit()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(configurationFile_name);
            int line_counter = 0;

            // The index of limit number in the configuration file
            int limitnumber = 1;
            string line;

            // Read limit number fron the file
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    try
                    {
                        string[] wordlist = line.Split('=');
                        groupsLimit = int.Parse(wordlist[limitnumber]);
                    }
                    catch
                    {
                        configurationException = configurationException + " confifuration file exist error(s), can not read groups limit.<br/>";
                    }
                }
                line_counter++;
            }

            fileread.Close();
            return groupsLimit;

        }

        /// <summary>
        /// The method is to get ponits per word from the configuration file 
        /// </summary>
        /// 
        /// <returns>return a int value which represents the points</returns>
        public int PointsPerWord()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(configurationFile_name);
            int line_counter = 0;

            // The index of point per word in the configuration file
            int pointnumber = 1;
            string line;

            // Read point per word from the file
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 1)
                {
                    try
                    {
                        string[] wordlist = line.Split('=');
                        pointsPerWord = int.Parse(wordlist[pointnumber]);
                    }
                    catch
                    {
                        configurationException = configurationException + " confifuration file exist error(s), can not read points per word.<br/>";
                    }
                }
                line_counter++;
            }

            fileread.Close();
            return pointsPerWord;
        }

        /// <summary>
        /// The method is to read the number of given intersecting letters
        /// </summary>
        /// 
        /// <returns>return a int value which represents the amount</returns>
        public int getTotalIntersect()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(configurationFile_name);
            int line_counter = 0;
            int indexOfIntersect = 0;

            // This is a counter to count the amount of total intersecting letter given in the file
            int totalIntersect = 0;
            string line;

            // Read file and count the amount of total intersecting letter given in the file
            while ((line = fileread.ReadLine()) != null)
            {
                try
                {
                    if (line_counter >= 2)
                    {
                        string[] line1 = line.Split(':');
                        if (line1[indexOfIntersect] == "INTERSECTING")
                        {
                            totalIntersect++;
                        }
                    }
                }
                catch
                {
                    configurationException = configurationException + " confifuration file exist error(s), can not read points per word.<br/>";
                }

                line_counter++;
            }

            fileread.Close();
            return totalIntersect;
        }

        /// <summary>
        /// The method is to read the number of given intersecting letters
        /// </summary>
        /// 
        /// <returns>return a int value which represents the amount</returns>
        public int getTotalNonIntersect()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(configurationFile_name);
            int line_counter = 0;
            int indexOfNonIntersect = 0;

            // This is a counter to count the amount of total nonintersecting letter given in the file
            int totalNonIntersect = 0;
            string line;

            // Read file and count the amount of total intersecting letter given in the file
            while ((line = fileread.ReadLine()) != null)
            {
                try
                {
                    if (line_counter >= 2)
                    {
                        string[] line1 = line.Split(':');
                        if (line1[indexOfNonIntersect] == "NONINTERSECTING")
                        {
                            totalNonIntersect++;
                        }
                    }
                }
                catch
                {
                    configurationException = configurationException + " confifuration file exist error(s), can not read points per word.<br/>";
                }

                line_counter++;
            }

            fileread.Close();
            return totalNonIntersect;
        }

        /// <summary>
        /// The method is to read intersecting letters and their points
        /// </summary>
        /// 
        /// <returns>return a string[,] value stores each intersecting letter and their corresponding points</returns>
        public string[,] IntersectLetterPoints()
        {

            System.IO.StreamReader fileread = new System.IO.StreamReader(configurationFile_name);
            int line_counter = 0;
            int indexOfPoint = 1;
            int indexOfLetter = 0;
            int counter = 0;

            // This variable is to store each letter of intersecting and its points
            string[,] intersectLetterPoint = new string[getTotalIntersect(), 2];
            string line;

            // Read file and store data into string[,]
            while ((line = fileread.ReadLine()) != null)
            {
                string[] wordList = line.Split(':');
                if (line_counter >= 2 && counter <= intersectLetterPoint.GetLength(0) - 1)
                {
                    try
                    {
                        string[] wordlist = line.Split(':');
                        string line1 = wordlist[indexOfPoint];
                        string letter = line1.Split('=')[indexOfLetter];
                        string p = line1.Split('=')[indexOfPoint];
                        intersectLetterPoint[counter, indexOfLetter] = letter;
                        intersectLetterPoint[counter, indexOfPoint] = p;
                        counter++;
                    }
                    catch
                    {
                        configurationException = configurationException + " confifuration file exist error(s), can not read intersecting letter points.<br/>";
                    }
                }

                line_counter++;
            }
            fileread.Close();
            return intersectLetterPoint;

        }

        /// <summary>
        /// The method is to read nonintersecting letters and their points
        /// </summary>
        /// 
        /// <returns>return a string[,] value stores each nonintersecting letter and their corresponding points</returns>
        public string[,] NonIntersectLetterPoints()
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(configurationFile_name);
            int line_counter = 0;
            int indexOfPoint = 1;
            int indexOfLetter = 0;
            int counter = 0;

            // This variable is to store each letter of intersecting and its points
            string[,] nonIntersectLetterPoint = new string[getTotalNonIntersect(), 2];
            string line;

            // Read file and store data into string[,]
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter >= 28 && counter <= nonIntersectLetterPoint.GetLength(0) - 1)
                {
                    try
                    {
                        string[] wordlist = line.Split(':');
                        string line1 = wordlist[indexOfPoint];
                        string letter = line1.Split('=')[indexOfLetter];
                        string p = line1.Split('=')[indexOfPoint];
                        nonIntersectLetterPoint[counter, indexOfLetter] = letter;
                        nonIntersectLetterPoint[counter, indexOfPoint] = p;
                        counter++;
                    }
                    catch
                    {
                        configurationException = configurationException + " confifuration file exist error(s), can not read intersecting letter points.<br/>";
                    }
                }
                line_counter++;
            }

            fileread.Close();
            return nonIntersectLetterPoint;
        }
    }
}
