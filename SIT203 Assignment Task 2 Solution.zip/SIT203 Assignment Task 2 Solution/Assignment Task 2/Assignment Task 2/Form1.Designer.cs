﻿namespace Assignment_Task_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crozzleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.computeScoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createNewCrozzleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crozzleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.configurationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.findBestCrozzleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.crozzleWeb = new System.Windows.Forms.WebBrowser();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.crozzleValidWeb = new System.Windows.Forms.WebBrowser();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.crozzleFileErrorWeb = new System.Windows.Forms.WebBrowser();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.configurationFileErrorWeb = new System.Windows.Forms.WebBrowser();
            this.saveBtn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.createNewCrozzleToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(750, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.crozzleToolStripMenuItem,
            this.configurationToolStripMenuItem,
            this.computeScoresToolStripMenuItem});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(121, 20);
            this.openToolStripMenuItem.Text = "Create New Crozzle";
            // 
            // crozzleToolStripMenuItem
            // 
            this.crozzleToolStripMenuItem.Name = "crozzleToolStripMenuItem";
            this.crozzleToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.crozzleToolStripMenuItem.Text = "Crozzle";
            this.crozzleToolStripMenuItem.Click += new System.EventHandler(this.crozzleToolStripMenuItem_Click);
            // 
            // configurationToolStripMenuItem
            // 
            this.configurationToolStripMenuItem.Enabled = false;
            this.configurationToolStripMenuItem.Name = "configurationToolStripMenuItem";
            this.configurationToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.configurationToolStripMenuItem.Text = "Configuration";
            this.configurationToolStripMenuItem.Click += new System.EventHandler(this.configurationToolStripMenuItem_Click);
            // 
            // computeScoresToolStripMenuItem
            // 
            this.computeScoresToolStripMenuItem.Enabled = false;
            this.computeScoresToolStripMenuItem.Name = "computeScoresToolStripMenuItem";
            this.computeScoresToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.computeScoresToolStripMenuItem.Text = "Find Best Crozzle";
            this.computeScoresToolStripMenuItem.Click += new System.EventHandler(this.computeScoresToolStripMenuItem_Click);
            // 
            // createNewCrozzleToolStripMenuItem
            // 
            this.createNewCrozzleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.crozzleToolStripMenuItem1,
            this.configurationToolStripMenuItem1,
            this.findBestCrozzleToolStripMenuItem});
            this.createNewCrozzleToolStripMenuItem.Name = "createNewCrozzleToolStripMenuItem";
            this.createNewCrozzleToolStripMenuItem.Size = new System.Drawing.Size(115, 20);
            this.createNewCrozzleToolStripMenuItem.Text = "Open Exist Crozzle";
            // 
            // crozzleToolStripMenuItem1
            // 
            this.crozzleToolStripMenuItem1.Name = "crozzleToolStripMenuItem1";
            this.crozzleToolStripMenuItem1.Size = new System.Drawing.Size(161, 22);
            this.crozzleToolStripMenuItem1.Text = "Crozzle";
            this.crozzleToolStripMenuItem1.Click += new System.EventHandler(this.crozzleToolStripMenuItem1_Click);
            // 
            // configurationToolStripMenuItem1
            // 
            this.configurationToolStripMenuItem1.Enabled = false;
            this.configurationToolStripMenuItem1.Name = "configurationToolStripMenuItem1";
            this.configurationToolStripMenuItem1.Size = new System.Drawing.Size(161, 22);
            this.configurationToolStripMenuItem1.Text = "Configuration";
            this.configurationToolStripMenuItem1.Click += new System.EventHandler(this.configurationToolStripMenuItem1_Click);
            // 
            // findBestCrozzleToolStripMenuItem
            // 
            this.findBestCrozzleToolStripMenuItem.Enabled = false;
            this.findBestCrozzleToolStripMenuItem.Name = "findBestCrozzleToolStripMenuItem";
            this.findBestCrozzleToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.findBestCrozzleToolStripMenuItem.Text = "Compute Scores";
            this.findBestCrozzleToolStripMenuItem.Click += new System.EventHandler(this.findBestCrozzleToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(13, 43);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(530, 438);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.crozzleWeb);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(522, 412);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Crozzle Display";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // crozzleWeb
            // 
            this.crozzleWeb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crozzleWeb.Location = new System.Drawing.Point(3, 3);
            this.crozzleWeb.MinimumSize = new System.Drawing.Size(20, 20);
            this.crozzleWeb.Name = "crozzleWeb";
            this.crozzleWeb.Size = new System.Drawing.Size(516, 406);
            this.crozzleWeb.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.crozzleValidWeb);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(522, 412);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Crozzle Validation";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // crozzleValidWeb
            // 
            this.crozzleValidWeb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crozzleValidWeb.Location = new System.Drawing.Point(0, 0);
            this.crozzleValidWeb.MinimumSize = new System.Drawing.Size(20, 20);
            this.crozzleValidWeb.Name = "crozzleValidWeb";
            this.crozzleValidWeb.Size = new System.Drawing.Size(522, 412);
            this.crozzleValidWeb.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.crozzleFileErrorWeb);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(522, 412);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Crozzle File Error";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // crozzleFileErrorWeb
            // 
            this.crozzleFileErrorWeb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crozzleFileErrorWeb.Location = new System.Drawing.Point(3, 3);
            this.crozzleFileErrorWeb.MinimumSize = new System.Drawing.Size(20, 20);
            this.crozzleFileErrorWeb.Name = "crozzleFileErrorWeb";
            this.crozzleFileErrorWeb.Size = new System.Drawing.Size(516, 406);
            this.crozzleFileErrorWeb.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.configurationFileErrorWeb);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(522, 412);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Configuration File Error";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // configurationFileErrorWeb
            // 
            this.configurationFileErrorWeb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.configurationFileErrorWeb.Location = new System.Drawing.Point(0, 0);
            this.configurationFileErrorWeb.MinimumSize = new System.Drawing.Size(20, 20);
            this.configurationFileErrorWeb.Name = "configurationFileErrorWeb";
            this.configurationFileErrorWeb.Size = new System.Drawing.Size(522, 412);
            this.configurationFileErrorWeb.TabIndex = 0;
            // 
            // saveBtn
            // 
            this.saveBtn.Enabled = false;
            this.saveBtn.Location = new System.Drawing.Point(577, 65);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(123, 31);
            this.saveBtn.TabIndex = 3;
            this.saveBtn.Text = "Save";
            this.saveBtn.UseVisualStyleBackColor = true;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(577, 139);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(123, 20);
            this.textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(577, 193);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(123, 20);
            this.textBox2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(574, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Level";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(573, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Scores";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 518);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crozzleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurationToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.WebBrowser crozzleWeb;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem computeScoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createNewCrozzleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crozzleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem configurationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem findBestCrozzleToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.WebBrowser crozzleValidWeb;
        private System.Windows.Forms.WebBrowser crozzleFileErrorWeb;
        private System.Windows.Forms.WebBrowser configurationFileErrorWeb;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    }
}

