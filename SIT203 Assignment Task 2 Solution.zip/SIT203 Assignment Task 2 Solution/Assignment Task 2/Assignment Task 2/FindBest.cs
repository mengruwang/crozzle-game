﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Task_2
{
    public class FindBest
    {
        //commonLetter(intersects) list  
        private List<char> commonLettersInEasyAndMedium;

        //nonintersects letters list  
        private List<char> nonIntersectsLetters;

        private bool BESTOK;
        // list of grid 
        private List<Grid> gridList = new List<Grid>();

        //crozzle score list for finding hignest score
        private List<int> crozzleScoreList = new List<int>();


        private Configuration con = new Configuration();
        private Crozzle crz = new Crozzle();

        //words used for creating crozzle in hard level
        private List<CrozzleWords> hardWords = new List<CrozzleWords> { };

        //crozzle list for finding best crozzle
        public List<Crozzle> crozzleList = new List<Crozzle>();

        //highest score index
        public int HighestIndex = 0;

        /// <summary>
        /// Constrctors 
        /// </summary>
        /// <param name="crzle">crozzle</param>
        /// <param name="config">configuratin=on</param>
        public FindBest(Crozzle crzle, Configuration config)
        {
            this.crz = crzle;
            this.con = config;
        }

        /// <summary>
        /// get intersects letters list
        /// </summary>
        /// <returns>return list with intersects letters</returns>
        public List<char> getCommonLetters()
        {
            return commonLettersInEasyAndMedium;
        }

        /// <summary>
        ///  get nonintersects letters list
        /// </summary>
        /// <returns>return list with noonintersects letters</returns>
        public List<char> getNonIntersectsLetters()
        {


            return nonIntersectsLetters;
        }

        /// <summary>
        /// display crozzle (for easy and medium level crozzle)
        /// </summary>
        /// <param name="row">row of display table</param>
        /// <param name="col">col of display table</param>
        /// <param name="wordsUsedForCrozzle">words used for creating crozzle</param>
        /// <returns>return a string that with html tags that can be displayed in the web browser</returns>
        public string displayEasyAndMedium(int row, int col, List<CrozzleWords> wordsUsedForCrozzle)
        {
            string[,] board = new string[row, col];
            string displayHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                <style>
                                table {
                                    width:360px;
                                }
                                table, td {
                                    border: 1px solid black;
                                    border-collapse: collapse;
                                }
                                td {
                                    width:24px;
                                    text-align: center;
                                }
                               tr{
                                   height:24px;
                               }
                                </style>
                                </head>
                                <body><table>";

            for (int i = 0; i < wordsUsedForCrozzle.Count; i++)
            {
                if (wordsUsedForCrozzle[i].orientation == "HORIZONTAL")
                {
                    for (int m = 0; m < wordsUsedForCrozzle[i].word.Length; m++)
                    {
                        board[wordsUsedForCrozzle[i].x, wordsUsedForCrozzle[i].y] = wordsUsedForCrozzle[i].word[m].ToString();
                        wordsUsedForCrozzle[i].y++;
                    }
                }
                if (wordsUsedForCrozzle[i].orientation == "VERTICAL")
                {
                    for (int m = 0; m < wordsUsedForCrozzle[i].word.Length; m++)
                    {
                        board[wordsUsedForCrozzle[i].x, wordsUsedForCrozzle[i].y] = wordsUsedForCrozzle[i].word[m].ToString();
                        wordsUsedForCrozzle[i].x++;
                    }
                }
            }
            for (int i = 0; i < board.GetLength(0); i++)
            {
                displayHTML = displayHTML + "<tr>";
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (board[i, j] != null)
                    {
                        displayHTML = displayHTML + "<td style='background:#CDCBCB '>" + board[i, j] + "</td>";
                    }
                    else
                    {
                        displayHTML = displayHTML + "<td>&nbsp;</td>";
                    }
                }
                displayHTML = displayHTML + "</tr>";
            }
            return displayHTML;
        }

        /// <summary>
        /// The second optimal Algorithm which may get more Scores (just for easy and medium)
        /// </summary>
        /// <param name="row">row of crozzle</param>
        /// <param name="col">column of crozzle</param>
        /// <param name="wordlist1">word list from crozzle</param>
        /// <returns>return a list of Crozzle Word that choosed for crozzle</returns>
        public List<CrozzleWords> Algorithm2(int row, int col, List<String> wordlist1)
        {
            int first = 0;
            commonLettersInEasyAndMedium = new List<char> { };
            nonIntersectsLetters = new List<char> { };
            List<CrozzleWords> choosed = new List<CrozzleWords> { };
          
            {
                CrozzleWords startWord = new CrozzleWords();
                startWord.word = wordlist1[first];
                if (startWord.word.Length == 2)
                {

                    CrozzleWords nextWord = new CrozzleWords();
                    int len = startWord.word.Length;
                    nextWord.word = findDiagonalStartWord(len, startWord.word[len - 1], wordlist1);

                    if (nextWord.word != null)
                    {
                        startWord.orientation = "HORIZONTAL";
                        startWord.x = 0;
                        startWord.y = 0;
                        nextWord.orientation = "VERTICAL";
                        nextWord.x = 0;
                        nextWord.y = 1;
                        choosed.Add(startWord);
                        choosed.Add(nextWord);
                        commonLettersInEasyAndMedium.Add(startWord.word[startWord.word.Length - 1]);
                        for (int a = 0; a < startWord.word.Length - 1; a++)
                        {
                            nonIntersectsLetters.Add(startWord.word[a]);
                        }
                        for (int a = 0; a < nextWord.word.Length - 1; a++)
                        {
                            nonIntersectsLetters.Add(nextWord.word[a]);
                        }
                        wordlist1.Remove(startWord.word);
                        wordlist1.Remove(nextWord.word);
                    }
                }

            }



            {
                int index = 0;
                List<string> newlist = new List<string> { };
                CrozzleWords startWord = new CrozzleWords();
                for (int m = 0; m < wordlist1.Count; m++)
                {
                    if (wordlist1[m].Length == 4)
                    {
                        newlist.Add(wordlist1[m]);
                    }
                }

                startWord.word = newlist[index];
                wordlist1.Remove(startWord.word);
                CrozzleWords nextWord = new CrozzleWords();
                int len = startWord.word.Length;

                nextWord.word = findDiagonalWord(len, startWord.word[len - 1], wordlist1);
                int counter = 0;
                while (nextWord.word == null)
                {

                    counter++;
                    nextWord.word = findDiagonalWord(len - counter, startWord.word[len - 1], wordlist1);

                }
                startWord.orientation = "HORIZONTAL";
                startWord.x = 3;
                startWord.y = 0;
                nextWord.orientation = "VERTICAL";
                nextWord.x = 0 + counter;
                nextWord.y = 3;
                choosed.Add(startWord);
                choosed.Add(nextWord);
                commonLettersInEasyAndMedium.Add(startWord.word[startWord.word.Length - 1]);
                for (int a = 0; a < startWord.word.Length - 1; a++)
                {
                    nonIntersectsLetters.Add(startWord.word[a]);
                }
                for (int a = 0; a < nextWord.word.Length - 1; a++)
                {
                    nonIntersectsLetters.Add(nextWord.word[a]);
                }
                wordlist1.Remove(startWord.word);
                wordlist1.Remove(nextWord.word);


            }

            {
                int index = 0;
                List<string> newlist = new List<string> { };
                CrozzleWords startWord = new CrozzleWords();
                for (int m = 0; m < wordlist1.Count; m++)
                {
                    if (wordlist1[m].Length == 6)
                    {
                        newlist.Add(wordlist1[m]);
                    }
                }

                startWord.word = newlist[index];
                wordlist1.Remove(startWord.word);
                CrozzleWords nextWord = new CrozzleWords();
                int len = startWord.word.Length;

                nextWord.word = findDiagonalWord(len, startWord.word[len - 1], wordlist1);
                int counter = 0;
                while (nextWord.word == null)
                {

                    counter++;
                    nextWord.word = findDiagonalWord(len - counter, startWord.word[len - 1], wordlist1);

                }
                startWord.orientation = "HORIZONTAL";
                startWord.x = 5;
                startWord.y = 0;
                nextWord.orientation = "VERTICAL";
                nextWord.x = 0 + counter;
                nextWord.y = 5;
                choosed.Add(startWord);
                choosed.Add(nextWord);
                commonLettersInEasyAndMedium.Add(startWord.word[startWord.word.Length - 1]);
                for (int a = 0; a < startWord.word.Length - 1; a++)
                {
                    nonIntersectsLetters.Add(startWord.word[a]);
                }
                for (int a = 0; a < nextWord.word.Length - 1; a++)
                {
                    nonIntersectsLetters.Add(nextWord.word[a]);
                }
                wordlist1.Remove(startWord.word);
                wordlist1.Remove(nextWord.word);
            }

            {
                int index = 0;
                List<string> newlist = new List<string> { };
                CrozzleWords startWord = new CrozzleWords();
                for (int m = 0; m < wordlist1.Count; m++)
                {
                    if (wordlist1[m].Length == 8)
                    {
                        newlist.Add(wordlist1[m]);
                    }
                }

                startWord.word = newlist[index];
                wordlist1.Remove(startWord.word);
                CrozzleWords nextWord = new CrozzleWords();
                int len = startWord.word.Length;

                nextWord.word = findDiagonalWord(len, startWord.word[len - 1], wordlist1);
                int counter = 0;
                while (nextWord.word == null)
                {

                    counter++;
                    nextWord.word = findDiagonalWord(len - counter, startWord.word[len - 1], wordlist1);

                }
                startWord.orientation = "HORIZONTAL";
                startWord.x = 7;
                startWord.y = 0;
                nextWord.orientation = "VERTICAL";
                nextWord.x = 0 + counter;
                nextWord.y = 7;
                choosed.Add(startWord);
                choosed.Add(nextWord);
                commonLettersInEasyAndMedium.Add(startWord.word[startWord.word.Length - 1]);
                for (int a = 0; a < startWord.word.Length - 1; a++)
                {
                    nonIntersectsLetters.Add(startWord.word[a]);
                }
                for (int a = 0; a < nextWord.word.Length - 1; a++)
                {
                    nonIntersectsLetters.Add(nextWord.word[a]);
                }
                wordlist1.Remove(startWord.word);
                wordlist1.Remove(nextWord.word);
            }

            {

                int index = 0;
                List<string> newlist = new List<string> { };
                CrozzleWords startWord = new CrozzleWords();
                for (int m = 0; m < wordlist1.Count; m++)
                {
                    if (wordlist1[m].Length == 9)
                    {
                        newlist.Add(wordlist1[m]);
                    }
                }

                startWord.word = newlist[index];
                wordlist1.Remove(startWord.word);
                CrozzleWords nextWord = new CrozzleWords();
                int len = startWord.word.Length;

                nextWord.word = findDiagonalWord(len, startWord.word[len - 1], wordlist1);
                int counter = 0;
                while (nextWord.word == null)
                {

                    counter++;
                    nextWord.word = findDiagonalWord(len - counter, startWord.word[len - 1], wordlist1);

                }
                startWord.orientation = "HORIZONTAL";
                startWord.x = 9;
                startWord.y = 1;
                nextWord.orientation = "VERTICAL";
                nextWord.x = 1 + counter;
                nextWord.y = 9;
                choosed.Add(startWord);
                choosed.Add(nextWord);
                commonLettersInEasyAndMedium.Add(startWord.word[startWord.word.Length - 1]);
                for (int a = 0; a < startWord.word.Length - 1; a++)
                {
                    nonIntersectsLetters.Add(startWord.word[a]);
                }
                for (int a = 0; a < nextWord.word.Length - 1; a++)
                {
                    nonIntersectsLetters.Add(nextWord.word[a]);
                }
                wordlist1.Remove(startWord.word);
                wordlist1.Remove(nextWord.word);
            }



            foreach (var s in choosed)
            {
                Console.WriteLine(s.word + "\n");
            }


            return choosed;
        }

        /// <summary>
        /// Calculate Score (foe easy and Medium level (matched Algorithm 2))
        /// </summary>
        /// <param name="cWords">words used in crozzle</param>
        /// <param name="cfig">configuration content</param>
        /// <returns>return int value for score</returns>
        public int getEasyAndMediumScore(List<CrozzleWords> cWords, Configuration cfig)
        {
            int score = 0;
            int colOfLetter = 0;
            int colOfPoints = 1;
            List<char> intersects = getCommonLetters();
            List<char> nonintersects = getNonIntersectsLetters();
         


            score = score + cWords.Count * cfig.getPointsPerWors();
            for (int i = 0; i < nonintersects.Count; i++)
            {
                for (int j = 0; j < cfig.getNonInterPoints().GetLength(0);j++ )
                    if (nonintersects[i].ToString() == cfig.getNonInterPoints()[j,colOfLetter])
                    score += int.Parse(cfig.getNonInterPoints()[j,colOfPoints]);
            }
            for (int i = 0; i < intersects.Count; i++)
            {
                for (int j = 0; j < cfig.getInterPoinsts().GetLength(0); j++)
                    if (intersects[i].ToString() == cfig.getInterPoinsts()[j, colOfLetter])
                        score += int.Parse(cfig.getInterPoinsts()[j, colOfPoints]);
            }



            return score;

        }

        /// <summary>
        /// find start word for algorithm2
        /// </summary>
        /// <param name="length">word length</param>
        /// <param name="commonLetter">intersects letter</param>
        /// <param name="diagonaList">word list that will be used for find words</param>
        /// <returns>return the result word in string value</returns>
        private String findDiagonalStartWord(int length, char commonLetter, List<string> diagonaList)
        {
            int firstLetter = 0;
            string find = null;
            List<string> newList = new List<string> { };
            for (int i = 0; i < diagonaList.Count; i++)
            {
                if (diagonaList[i].Length == length)
                {
                    newList.Add(diagonaList[i]);
                }
            }

            foreach (var s in newList)
            {
                if (s[firstLetter] == commonLetter)
                {
                    find = s;
                }
            }

            return find;
        }

        /// <summary>
        /// find all other word for algorithm2 except start word
        /// </summary>
        /// <param name="length">word length</param>
        /// <param name="commonLetter">intersects letter</param>
        /// <param name="diagonaList">word list that will be used for find words</param>
        /// <returns>return the result word in string value</returns>
        public String findDiagonalWord(int length, char commonLetter, List<string> diagonaList)
        {
            int lastLetter = length - 1;
            string find = null;
            List<string> newList = new List<string> { };
            for (int i = 0; i < diagonaList.Count; i++)
            {
                if (diagonaList[i].Length == length)
                {
                    newList.Add(diagonaList[i]);
                }
            }

            foreach (var s in newList)
            {
                if (s[lastLetter] == commonLetter)
                {
                    find = s;
                }
            }

            return find;
        }

       


        /// <summary>
        /// compute word score
        /// </summary>
        /// <param name="wds">wds</param>
        /// <param name="con1">con1</param>
        /// <returns>return a int value with its intersects score</returns>
        private int computeCrossWord(String wds, Configuration con1)
        {
            int score = 0;
            int colOfLetter = 0;
            int colOfPoints = 1;
           
            for (int i = 0; i < wds.Length; i++)
            {

                for (int j = 0; j < con1.getInterPoinsts().GetLength(0); j++)
                {
                    
                    if (wds[i].ToString() == con1.getInterPoinsts()[j, colOfLetter])
                        score += int.Parse(con1.getInterPoinsts()[j, colOfPoints]);

                }
            }
            return score;
        }


        /// <summary>
        /// Algorithm 1, which is greedy algorithm 1
        /// </summary>
        /// <param name="row">crozzle row</param>
        /// <param name="col">crozzle col</param>
        /// <param name="WORD_LIST_CROZZLE">crozzle word list</param>
        /// <returns></returns>
        public Crozzle Algorithm1(int row, int col, List<String> WORD_LIST_CROZZLE)
        {
           
            int indexOfFirst = 0;
            int AmountOfCrozzle = 0;
            int expandRow = row +2;
            int expandCol = col +2;

            Crozzle BEST = crz;
            Grid grid = new Grid(row, col);
            List<String> crosswords = new List<String>();
            List<String> HighCrossList = OrderByCrossScore(WORD_LIST_CROZZLE);

            crosswords.Add(HighCrossList[indexOfFirst]);
            int valueOfFirst = computeCrossWord(HighCrossList[indexOfFirst], con);
            for (int i = 1; i < HighCrossList.Count; i++)
            {
                int values = computeCrossWord(HighCrossList[i], con);
                if (values == valueOfFirst)
                {
                    crosswords.Add(HighCrossList[i]);
                }
            }

            for (int i = 0; i < crosswords.Count; i++)
                {
                    for (int j = 1; j <= crz.getRows(); j++)
                    {

                        CrozzleWords startWord;
                        Crozzle crozzleCreate = new Crozzle();
                        Grid table = new Grid(expandRow, expandCol);
                        table.gridborad = new String[expandRow, expandCol];
                        for (int width = 0; width < row + 2;width++)
                        {
                            for (int height = 0; height < col + 2; height++)
                            {
                                table.gridborad[width, height] = "";
                            }
                        }
                        int crozzleScore;
                        List<String> fetchedList = HighCrossList;
                        startWord = new CrozzleWords("HORIZONTAL", j, 1, crosswords[i]);
                        table.insert(startWord);
                        crozzleCreate.PutIn(startWord);
                        crozzleCreate.PutInHardWords(startWord);
                        fetchedList.Remove(startWord.word);
                        CrozzleWords nextwd = findCross(fetchedList, crosswords[i]);
                        while (nextwd.word != null)
                        {
                            table.insert(nextwd);
                            crozzleCreate.PutIn(nextwd);
                            crozzleCreate.PutInHardWords(nextwd);
                            fetchedList.Remove(nextwd.word);
                            nextwd = findCross(fetchedList, nextwd.word);
                        }
                        CrozzleWords nextWord2 = findBestMatchWord(table, fetchedList);
                        while (nextWord2.word != null)
                        {
                            table.insert(nextWord2);
                            crozzleCreate.PutIn(nextWord2);
                            crozzleCreate.PutInHardWords(nextWord2);
                            fetchedList.Remove(nextWord2.word);
                            nextWord2 = findBestMatchWord(table, fetchedList);
                        }

                        crozzleScore = CalculateScore(crozzleCreate, con);
                        crozzleList.Add(crozzleCreate);
                        gridList.Add(table);
                        crozzleScoreList.Add(crozzleScore);
                        AmountOfCrozzle++;
                    }
            }
            BEST.crzwordList = crozzleList[crozzleScoreList.IndexOf(crozzleScoreList.Max())].crzwordList;
            return BEST;

        }

        /// <summary>
        /// Find best matched word for algorithm 1
        /// </summary>
        /// <param name="table">crozzle table</param>
        /// <param name="words">word list used for find best word</param>
        /// <returns></returns>
        private CrozzleWords findBestMatchWord(Grid table, List<String> words)
        {

            int startX = 0;
            int startY = 0;
            String data = "";

            CrozzleWords NEW_WORD;
            CrozzleWords BEST = new CrozzleWords();

            BESTOK = false;
            String direction = null;

            for (int k = 0; k < words.Count; k++)
            {
                String match = words[k];
                int len = match.Length;
                int width = table.numOfRows;
                int height = table.numOfCols;
                for (int i = 0; i < len; i++)
                {
                    for (int x = 1; x < width - 1; x++)
                    {
                        for (int y = 1; y < height - 1; y++)
                        {
                            if (table.gridborad[x, y] == match[i].ToString())
                            {
                                if (i == 0)
                                {
                                    int vertical = 0;
                                    int horizontal = 0;
                                    for (int m = 1; m < len; m++)
                                    {
                                        if (y + m < width - 1 && table.gridborad[x, y + m].Length == 0 && table.gridborad[x, y - 1].Length == 0 &&  table.gridborad[x, y + 1].Length == 0
                                            && table.gridborad[x - 1, y + m].Length == 0 && table.gridborad[x + 1, y + m].Length == 0)
                                        {
                                            if(y+len-i+1<height-1 && table.gridborad[x, y + len - i + 1].Length == 0 && y+1<height-1 && x+m<width-1 && table.gridborad[x + m, y +1].Length == 0
                                    && x+len<height-1 && table.gridborad[x+len, y].Length == 0)
                                            vertical++;
                                        }
                                        else if (x + m < width - 1 && table.gridborad[x + m, y].Length == 0 && table.gridborad[x - 1, y].Length == 0
                                            && table.gridborad[x + m, y + 1].Length == 0 && table.gridborad[x + m, y - 1].Length == 0)
                                        {
                                            if (x + len - i < width - 1 && table.gridborad[x + len - i, y].Length == 0)
                                            horizontal++;
                                        }

                                    }
                                    if (vertical == len - 1)
                                    {
                                        direction = "HORIZONTAL";
                                        startX = x;
                                        startY = y;
                                        data = match;
                                        BESTOK = true;
                                        goto _RESULT;
                                    }
                                    if (horizontal == len - 1)
                                    {
                                        direction = "VERTICAL";
                                        startX = x;
                                        startY = y;
                                        data = match;
                                        BESTOK = true;
                                        goto _RESULT;
                                    }
                                }
                                else if (i == len - 1)
                                {
                                    int vertical = 0;
                                    int horizontal = 0;
                                    for (int m = 1; m < len; m++)
                                    {
                                        if (y - m > 0 && table.gridborad[x, y - m].Length == 0 && table.gridborad[x, y + 1].Length == 0
                                            && table.gridborad[x - 1, y - m].Length == 0 && table.gridborad[x + 1, y - m].Length == 0)
                                        {
                                            if(y-i>0 && table.gridborad[x, y - i - 1].Length == 0 && y+len-i<height-1 && table.gridborad[x, y + len - i].Length == 0 && x-len>0
                                     && table.gridborad[x-len, y].Length == 0 )
                                            vertical++;
                                        }
                                        else if (x - m > 0 && table.gridborad[x - m, y].Length == 0 && table.gridborad[x + 1, y].Length == 0
                                            && table.gridborad[x - m, y + 1].Length == 0 && table.gridborad[x - m, y - 1].Length == 0)
                                        {
                                            if (table.gridborad[x + len - i, y - 1].Length == 0)
                                            horizontal++;
                                        }

                                    }
                                    if (vertical == len - 1)
                                    {
                                        direction = "HORIZONTAL";
                                        startX = x;
                                        startY = y - len + 1;
                                        data = match;
                                        BESTOK = true;
                                        goto _RESULT;
                                    }
                                    if (horizontal == len - 1)
                                    {
                                        direction = "VERTICAL";
                                        startX = x - len + 1;
                                        startY = y;
                                        data = match;
                                        BESTOK = true;
                                        goto _RESULT;
                                    }
                                }
                                else
                                {
                                    int vertical = 0;
                                    int horizontal = 0;
                                    for (int m = 1; m <= i; m++)
                                    {
                                        if (y - m > 0 && table.gridborad[x, y - m].Length == 0 && table.gridborad[x - 1, y - m].Length == 0 && table.gridborad[x , y - m-1].Length == 0 
                                            && table.gridborad[x + 1, y - m].Length == 0 && table.gridborad[x + 1, y - m-1].Length == 0)
                                        {
                                            vertical++;
                                        }
                                        else if (x - m > 0 && table.gridborad[x - m, y].Length == 0 && table.gridborad[x - m-1, y].Length == 0 && table.gridborad[x - m, y + 1].Length == 0 && table.gridborad[x - m-1, y + 1].Length == 0
                                            && table.gridborad[x - m, y - 1].Length == 0)
                                        {
                                            if (x - i - 1 > 0 && table.gridborad[x - i - 1, y].Length == 0 && y + len - i - 1 < height - 1 && table.gridborad[x, y + len - i - 1].Length == 0)
                                                horizontal++;
                                        }
                                    }
                                    for (int m = 1; m < len - i; m++)
                                    {
                                        if (y + m < height - 1 && table.gridborad[x, y + m].Length == 0 && table.gridborad[x - 1, y + m].Length == 0 && table.gridborad[x, y + m+1].Length == 0
                                            && table.gridborad[x + 1, y + m].Length == 0 && table.gridborad[x - 1, y + m+1].Length == 0)
                                        {
                                            vertical++;
                                        }
                                        else if (x + m < width - 1 && table.gridborad[x + m, y].Length == 0 && table.gridborad[x + m, y + 1].Length == 0
                                            && table.gridborad[x + m, y - 1].Length == 0)
                                        {
                                            if (x - i - 1 > 0 && table.gridborad[x - i - 1, y].Length == 0 && y + len - i - 1 < height - 1 && table.gridborad[x, y + len - i - 1].Length == 0)
                                                horizontal++;
                                        }
                                    }
                                    if (vertical == len - 1)
                                    {
                                        direction = "HORIZONTAL";
                                        startX = x;
                                        startY = y - i;
                                        data = match;
                                        BESTOK = true;
                                        goto _RESULT;
                                    }
                                    if (horizontal == len - 1)
                                    {
                                        direction = "VERTICAL";
                                        startX = x - i;
                                        startY = y;
                                        data = match;
                                        BESTOK = true;
                                        goto _RESULT;
                                    }
                                }
                            }

                        }
                    }
                }
            }
        _RESULT:
            if (BESTOK == false)
            {
                NEW_WORD = new CrozzleWords();
            }
            else
            {
                NEW_WORD = new CrozzleWords(direction, startX, startY, data);
            }

            hardWords.Add(NEW_WORD);
            return NEW_WORD;
        }

        /// <summary>
        /// Find word has high score  letters (from z to a ,z is with more score)
        /// </summary>
        /// <param name="words">list of word</param>
        /// <param name="data">data will be compared</param>
        /// <returns>return a CroozleWord result</returns>
        private CrozzleWords findCross(List<String> words, String data)
        {
            List<String> CrossList = new List<String>();

            for (int i = 0; i < words.Count; i++)
            {
                String same = commonLetter(data, words[i]);
                if (data != words[i] && same.Length != 0)
                {
                    CrossList.Add(words[i]);
                }
            }

            List<String> fetchedList = CrossList;

            String find = HighestCrossScore(data, fetchedList);
            CrozzleWords NEW_WORD;
           
            do
            {
                NEW_WORD = new CrozzleWords();
                Boolean judge = BESTOK;
                    
                if (judge == false)
                {
                    fetchedList.Remove(find);
                    if (fetchedList.Count != 0)
                    {
                        find = HighestCrossScore(data, fetchedList);
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    BESTOK = true;
                }

            } while (BESTOK == false);
            
            hardWords.Add(NEW_WORD);

            return NEW_WORD;

        }


        /// <summary>
        /// Calculate Total Crozzle Score
        /// </summary>
        /// <param name="crozzle">crozzle</param>
        /// <param name="configuration">configuration</param>
        /// <returns></returns>
        public int CalculateScore(Crozzle crozzle, Configuration configuration)
        {
            int Score;         
            int colOfLetter=0;
            int colOfPoints=1;
            Score = (crozzle.crzwordList.Count) * configuration.getPointsPerWors();
            for (int i = 0; i < crozzle.getRows(); i++)
            {
                for (int j = 0; j < crozzle.getCols(); j++)
                {
                    
                        if (crozzle.unitTimesOfGrid[i, j] == 1)
                        {
                            for (int m = 0; m < configuration.getNonInterPoints().GetLength(0);m++ )
                                if (crozzle.board[i, j].ToString() == configuration.getNonInterPoints()[m,colOfLetter])
                                    Score += int.Parse(configuration.getNonInterPoints()[m, colOfPoints]);
                        }
                        else if (crozzle.unitTimesOfGrid[i, j] >1)
                        {
                            for (int m = 0; m < configuration.getInterPoinsts().GetLength(0); m++)
                                if (crozzle.board[i, j].ToString() == configuration.getInterPoinsts()[m, colOfLetter])
                                    Score += int.Parse(configuration.getInterPoinsts()[m, colOfPoints]);
                        }
                }
            }
            
            return Score;
        }

    
        /// <summary>
        /// Find word that may get highest score
        /// </summary>
        /// <param name="Word">word will be compared and find word with common letter with it</param>
        /// <param name="Wordlist">Wordlist that used for finding word</param>
        /// <returns>return a string result value</returns>
        private String HighestCrossScore(String Word, List<String> Wordlist)
        {
            int index = 0;
            String CrossWord;
            int colOfLetter=0;
            int colOfPoints=1;
            int score = 0;
            List<int> newlist = new List<int>();
         
            for (int i = 0; i < Wordlist.Count; i++)
            {
                String match = commonLetter(Word, Wordlist[i]);

                for (int j = 0; j < con.getInterPoinsts().GetLength(0); j++)
                {
                    if (match[index].ToString() == con.getInterPoinsts()[j, colOfLetter])
                    {
                        score = int.Parse(con.getInterPoinsts()[j ,colOfPoints]);
                    }
                }
                newlist.Add(score);
            }
            
            CrossWord = Wordlist[newlist.IndexOf(newlist.Max())];
            return CrossWord;

        }

        /// <summary>
        /// Find common letter btween two words
        /// </summary>
        /// <param name="wordA">word A</param>
        /// <param name="wordB">word B</param>
        /// <returns>return a common letter that has most high score</returns>
        private String commonLetter(String wordA, String wordB)
        {
            List<int> SCORE_LIST = new List<int>();
            List<String> commonLetter = new List<String>();
            int colOfLetter=0;
            int colOfPoints=1;
            
            for (int i = 0; i < wordA.Length; i++)
            {
                for (int j = 0; j < wordB.Length; j++)
                {
                    if (wordA[i] == wordA[j])
                    {
                        commonLetter.Add(wordA[i].ToString());
                        break;
                    }
                }

            }
            for (int i = 0; i < commonLetter.Count; i++)
            {
               
                for(int j=0;j<con.getInterPoinsts().GetLength(0);j++)
                    if (commonLetter[i] == con.getInterPoinsts()[j, colOfLetter])
                    {
                       
                       int SCORE = int.Parse(con.getInterPoinsts()[j, colOfPoints]);
                       SCORE_LIST.Add(SCORE);
                    }
              

            }
            
            return commonLetter[SCORE_LIST.IndexOf(SCORE_LIST.Max())];
        }


        /// <summary>
        /// sort list by score in each element
        /// </summary>
        /// <param name="FetchedList">list will be sorted</param>
        /// <returns>return a new lst that after sorted</returns>
        private List<String> OrderByCrossScore(List<String> FetchedList)
        {
            List<String> WORD_NEW_LIST = new List<String>();
            FetchedList.Sort(findHigherCrossScore);
            WORD_NEW_LIST = FetchedList;
            return WORD_NEW_LIST;

        }
         /// <summary>
        /// find word which may have higher score
        /// </summary>
        /// <param name="dataA">dataA</param>
        /// <param name="dataB">dataB</param>
        /// <returns>return int score differential between two params</returns>
        private int findHigherCrossScore(String cmpword1, String cmpword2)
        {
            int scoreA = computeCrossWord(cmpword1, con);
            int scoreB = computeCrossWord(cmpword2, con);
            return scoreB - scoreA;
        }

        /// <summary>
        /// display crozzle 
        /// </summary>
        /// <param name="crozzle">crozzle that will be displayed</param>
        /// <returns>return a string that with html tags that can be displayed in the web browser</returns>
        public string display(Crozzle crozzle)
        {

            String crozzleHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                <style>
                                table {
                                    width:360px;
                                }
                                table, td {
                                    border: 1px solid black;
                                    border-collapse: collapse;
                                }
                                td {
                                    width:24px;
                                    text-align: center;
                                }
                               tr{
                                   height:24px;
                               }
                                </style>
                                </head>
                                <body><table>";
            int row = crz.getRows();
            int col = crz.getCols();
            for (int i = 0; i < row; i++)
            {
                crozzleHTML += "<tr>";
                for (int j = 0; j < col; j++)
                {
                    if (crozzle.board[i, j] != null)
                        crozzleHTML += "<td style='background:#CDCBCB '>" + crozzle.board[i, j] + "</td>";
                    else
                        crozzleHTML += "<td >" + crozzle.board[i, j] + "</td>";
                }
                crozzleHTML += "</tr>";
            }

            crozzleHTML += "</table></body></html>";


            return crozzleHTML;
        }
    }
}
