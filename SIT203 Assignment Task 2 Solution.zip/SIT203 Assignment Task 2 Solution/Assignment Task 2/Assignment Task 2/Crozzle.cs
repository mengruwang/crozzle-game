﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Assignment_Task_2
{
    public class Crozzle
    {
        // crozzle level
        private string level;

        //crozzle rows
        private int rows;

        // crozzle cols
        private int cols;

        // the amout of crozzle words given int the file 
        private int amount;

        private bool flag;

        // all words given in the file 
        private string[] wordlist;

        // copy file headers - used for save crozzle to a file
        private List<String> copyHeaders;

        //a list that sort word in the file from short to long
        private List<String> ListFromShortToLong;

        // return a array that each unit store how many time that used for store the char
        public int[,] unitTimesOfGrid;

        //word used for new crozzle, when create crozzle in the hard level
        public List<CrozzleWords> choosedhardWord = new List<CrozzleWords>();
        public String[,] board;

        // all words choosed for create a new crozzle
        public List<CrozzleWords> crzwordList = new List<CrozzleWords>();

        //all words given in the file
        public List<String> wordlist2;
       

        /// <summary>
        /// This method is to get headers value in the file
        /// </summary>
        /// <returns>return the list with header values</returns>
        public List<String> getHeaders()
        {
            return copyHeaders;
        }

        /// <summary>
        /// This method is to get amount of all words
        /// </summary>
        /// <returns>return a int value with amout</returns>
        private int getAmout()
        {
            return amount;
        }

        /// <summary>
        /// This method is to get rows of a crozzle
        /// </summary>
        /// <returns>return a int value with rows</returns>
        public int getRows()
        {
            return rows;
        }

        /// <summary>
        /// This method is to get cols of a crozzle
        /// </summary>
        /// <returns>return a int value with cols</returns>
        public int getCols()
        {
            return cols;
        }
        
        /// <summary>
        /// Put into a list when the word choosed for creater a new crozzle
        /// </summary>
        /// <param name="wd">CrozzleWords object that prepare to put into list</param>
        public void PutIn(CrozzleWords wd)
        {
            this.crzwordList.Add(wd);
        }

        /// <summary>
        /// Get level of crozzle
        /// </summary>
        /// <returns>return a string value with crozzle level</returns>
        public string getLevel()
        {
            return level;
        }

        /// <summary>
        /// Sort string in a list by length
        /// </summary>
        /// <param name="words">string that will be sort</param>
        /// <returns>return variable that after soted</returns>
        static IEnumerable<string> SortByLength(IEnumerable<string> words)
        {
            // Use LINQ to sort the array received and return a copy.
            var sorted = from word in words
                         orderby word.Length ascending
                         select word;
            return sorted;
        }

        /// <summary>
        /// Sort list by length
        /// </summary>
        /// <returns>return the list that after sorted</returns>
        public List<String> getListByLength()
        {
            ListFromShortToLong = new List<string> { };

            foreach (var s in SortByLength(wordlist))
            {
                ListFromShortToLong.Add(s);
                //Console.WriteLine(s + "#");
            }

            return ListFromShortToLong;
        }

        /// <summary>
        /// When crozzle is hard level, put choosed word into  the list 
        /// </summary>
        /// <param name="c"> choosed word that used for crozzle creation</param>
        /// <returns>return the list</returns>
        public List<CrozzleWords> PutInHardWords(CrozzleWords c)
        {
            choosedhardWord.Add(c);
            return choosedhardWord;
        }

        /// <summary>
        /// Read crozzle file
        /// </summary>
        /// <param name="FILE_NAME">crozzle file name that will be read</param>
        public void ReadFile(string FILE_NAME)
        {
            copyHeaders = new List<string> { };
            System.IO.StreamReader fileread = new System.IO.StreamReader(FILE_NAME);

            int line_counter = 0;
            int indexOfLevel = 0;
            int indexOfAmount = 1;
            int indexOfWidth = 2;
            int indexOfHeight = 3;
            string line;

            // Read file and get all words in the list from the file
            while ((line = fileread.ReadLine()) != null)
            {
                
                    if (line_counter == 0)
                    {
                        string[] headers = line.Split(',');
                        level = headers[indexOfLevel];
                        amount = int.Parse(headers[indexOfAmount]);
                        rows = int.Parse(headers[indexOfWidth]);
                        cols = int.Parse(headers[indexOfHeight]);
                        copyHeaders.Add(line);
                    }
                    if (line_counter > 0)
                    {
                        wordlist = line.Split(',');
                        wordlist2 = new List<string>(wordlist);
                        copyHeaders.Add(line);
                    }
                    line_counter++;
                
            }
                
            fileread.Close();
            
        }
        /// <summary>
        /// put crozzle word into a table format that can be display
        /// </summary>
        public void changeToTable()
        {
            board = new string[rows + 10, cols + 10];
            unitTimesOfGrid = new int[rows + 10, cols + 10];
            for (int i = 0; i < crzwordList.Count; i++)
            {
                CrozzleWords wd = crzwordList[i];
                if (wd.orientation == "HORIZONTAL")
                {
                    for (int positionX = wd.x - 1, positionY = wd.y - 1, j = 0; j < wd.word.Length; positionY++, j++)
                    {
                        board[positionX, positionY] = wd.word[j].ToString();
                        unitTimesOfGrid[positionX, positionY]++;

                    }
                }
                if (wd.orientation == "VERTICAL")
                {
                    for (int positionX = wd.x - 1, positionY = wd.y - 1, j = 0; j < wd.word.Length; j++)
                    {
                        board[positionX, positionY] = wd.word[j].ToString();
                        unitTimesOfGrid[positionX, positionY]++;
                        positionX++;
                    }
                }
            }
        }


        /// <summary>
        /// Validate crozzle file
        /// </summary>
        /// <returns>return string value with error message if had</returns>
        public string ValidateFile(string file_name)
        {
            System.IO.StreamReader fileread = new System.IO.StreamReader(file_name);
            string errorHTML;
            int level = 0;
            int totalRows = 2;
            int totalCols = 3;
            int numberOfWords = 1;
            int line_counter = 0;
            int errorCounter = 0;
            string line;
            string error_message = null;

            // Using regular expression to check if words in the file have following illegal symbols
            string validCharacter = @"^([a-zA-Z]+)$";
            string validDigit = @"^([0-9]+)$";



            // Read file and check each line values if there is any voilations
            while ((line = fileread.ReadLine()) != null)
            {
                if (line_counter == 0)
                {
                    // Check if there is six values in the crozzle file header
                    try
                    {
                        string[] wordlist = line.Split(',');
                        if (wordlist.Length == 6)
                        {
                            error_message = error_message + null;
                        }
                        else if (wordlist.Length < 6)
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the file header lost some values.<br/>";
                        }
                        else if (wordlist.Length > 6)
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", there is more than six values in the file header .<br/>";
                        }
                        for (int i = 0; i < wordlist.Length; i++)
                        {
                            if (wordlist[i] != "")
                            {
                                error_message = error_message + null;
                            }

                            else
                            {
                                errorCounter++;
                                error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", value(s) in the file header is not in correct format.<br/>";
                            }
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the file header lost some values.<br/>";
                    }

                    // Check if the level of crozzle is 'EASY', 'MEDIUM' or 'HARD'
                    try
                    {
                        string[] wordlist = line.Split(',');
                        if (wordlist[level] == "EASY" || wordlist[level] == "MEDIUM" || wordlist[level] == "HARD")
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;

                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + " (level format error(s))\n.<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;

                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + " (level format error(s))\n.<br/>";
                    }

                    // Check if the the number of all words is match 0-9 and in the valid range 10-1000
                    try
                    {
                        string[] wordlist = line.Split(',');
                        Match m = Regex.Match(wordlist[numberOfWords], validDigit);

                        if (m.Success && (int.Parse(wordlist[numberOfWords]) >= 10 && int.Parse(wordlist[numberOfWords]) <= 1000))
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of all words is " + wordlist[numberOfWords] + " in the crozzle is not within 10 to 1000.<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of rows in the crozzle is not within 10 to 1000.<br/>";

                    }

                    // Check if the the number of rows is match 0-9 and in the valid range 4-400
                    try
                    {
                        string[] wordlist = line.Split(',');
                        Match m = Regex.Match(wordlist[totalRows], validDigit);

                        if (m.Success && (int.Parse(wordlist[totalRows]) >= 4 && int.Parse(wordlist[totalRows]) <= 400))
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of rows in the crozzle is not within 4 to 400.<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of rows in the crozzle is not within 4 to 400.<br/>";

                    }

                    // Check if the total columns of crozzle is match 0-9 and in the valid range 8-800
                    try
                    {
                        string[] wordlist = line.Split(',');
                        Match m = Regex.Match(wordlist[totalCols], validDigit);

                        if (m.Success && (int.Parse(wordlist[totalCols]) >= 8 && int.Parse(wordlist[totalCols]) <= 800))
                        {
                            error_message = error_message + null;
                        }
                        else
                        {
                            errorCounter++;
                            error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of columns in the crozzle is not within 8 to 800.<br/>";
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the actual number of columns in the crozzle is not within 8 to 800.<br/>";

                    }

                }

                // Check if there is any voilations in line 2 (for file)
                else if (line_counter == 1)
                {
                    // Check if words contains illegal symbol or digit
                    try
                    {
                        string[] wordlist = line.Split(',');

                        for (int i = 0; i < wordlist.Length; i++)
                        {
                            Match m = Regex.Match(wordlist[i], validCharacter);
                            if (!m.Success)
                            {
                                errorCounter++;
                                error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the illegal symbol in the word " + " ' " + wordlist[i] + " ' " + " .<br/>";
                            }
                            else
                            {
                                error_message = error_message + null;
                            }
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", the number of words in the list is not in the required range.<br/>";

                    }

                    // check if the word list has duplicated word(s)
                    try
                    {
                        string[] wordlist = line.Split(',');
                        for (int i = 1; i < wordlist.Length; i++)
                        {
                            flag = false;
                            for (int j = 0; j < i; j++)
                            {
                                if (wordlist[j] == wordlist[i])
                                {
                                    flag = true;
                                }
                            }
                            if (flag == false)
                            {
                                error_message = error_message + null;
                            }
                            else
                            {
                                errorCounter++;
                                error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + ", word " + wordlist[i] + " is duplicated.<br/>";
                            }
                        }
                    }
                    catch
                    {
                        errorCounter++;
                        error_message = error_message + errorCounter + ". Crozzle file error(s) detected in the line " + (line_counter + 1) + " words in the file violate rules.<br/>";
                    }

                }

               
                line_counter++;
            }

            fileread.Close();

            if (error_message != "")
            {

                errorHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                </head><strong> Crozzle File Validation</strong><br/>
                                <body>" + error_message + "</body></html>";
            }

            else
            {
                errorHTML = @"<!DOCTYPE html>
                                <html>
                                <head>
                                </head><strong> Crozzle File Validation</strong><br/>
                                <body> No error(s) detected in the crozzle file ! </body></html>";


            }
            return errorHTML;
        }

       

       
    }
}
       
       

