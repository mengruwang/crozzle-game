﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Task_2
{
    class Grid
    {
        public int numOfRows;
        public int numOfCols;
        public String[,] gridborad;
        public Grid(int row, int col)
        {
            this.numOfRows = row;
            this.numOfCols = col;
        }
        public void insert(CrozzleWords word)
        {

            int length = word.word.Length;
            if (word.orientation == "HORIZONTAL")
            {
                for (int i = 0; i < length; i++)
                {
                    gridborad[word.x, word.y + i] = word.word[i].ToString();
                }

            }
            else
            {
                for (int i = 0; i < length; i++)
                {
                    gridborad[word.x + i, word.y] = word.word[i].ToString();
                }
            }

        }
       
    }
}
