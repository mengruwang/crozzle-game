﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assignment_Task_2;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;


namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// This Test Method is used for testing when open a crozle file and read the file success
        /// </summary>
        [TestMethod]
        public void TestCrozzleFileRead()
        {
            // Arrange a crozzle obj
            Crozzle newCrz = new Crozzle();

            //Act read file method
            newCrz.ReadFile("Test 1 - EASY.txt");

            // call functions that can get values in the file
            string level = newCrz.getLevel();
            int row = newCrz.getRows();
            int col = newCrz.getCols();
            
            // Assert if the result is true
            Assert.IsTrue(level == "EASY");
            Assert.IsTrue(row==10);
            Assert.IsTrue(col==10);
            
        }

        /// <summary>
        /// This Test Method is used for testing when open a configuration file and read the file success
        /// </summary>
         [TestMethod]
        public void TestConfigutationFileRead()
        {
            // Arrange a configuration obj
             Configuration newCon = new Configuration();
             
             int colOfPoints=1;

             //Act ReasdFile() method that read content in configuration file
             newCon.ReadFile("Test 1 - EASY Configuration.txt");
             // call method that can get values in the configuration file
             int limit = newCon.getGroupLimit();
             int points = newCon.getPointsPerWors();
             string[,] nonIn=newCon.getNonInterPoints();
             string[,] In = newCon.getInterPoinsts();

             // Assert if the value read is true as expected
             Assert.IsTrue(limit == 1000);
             Assert.IsTrue(points == 0);
             for (int i = 0; i < nonIn.GetLength(0); i++)
             {
                 Assert.IsTrue(int.Parse(nonIn[i, colOfPoints]) == 1);
                 Assert.IsTrue(int.Parse(In[i, colOfPoints] )== 1);
             }

        }

        /// <summary>
         /// This Test Method is used for testing Algorithm for EADY Crozzle if their Scores up to 50
        /// </summary>
        [TestMethod]
        public void TestCrozzleScore()
        {
            // Arrange cozzle and configuration object and get relevant content
            Crozzle crozzle = new Crozzle();
            Configuration configuration = new Configuration();
            crozzle.ReadFile("Test 1 - EASY.txt");
            configuration.ReadFile("Test 1 - EASY Configuration.txt");

            // Arrange a greedy object that can contains algorithm
            FindBest BEST_CROZZLE = new FindBest(crozzle, configuration);
            
           
            // Act Algorithm and calculate Scores
            int score = BEST_CROZZLE.getEasyAndMediumScore(BEST_CROZZLE.Algorithm2(crozzle.getRows(), crozzle.getCols(), crozzle.getListByLength()), configuration);
               
            // Assert if the score for current crozzle and configuration (easy level) is greater than 50
            Assert.IsTrue(score>50);  
        }


        /// <summary>
        /// This testing method is to test if can find a best word in Easy or Medium level
        /// </summary>
        [TestMethod]
        public void TestFindWordMethod()
        {
           // Arrange Crozzle, Configuraion, Greedy, CrozzleWords object
            Crozzle crz = new Crozzle();
            Configuration cfig = new Configuration();
            FindBest newGrdy = new FindBest(crz, cfig);
            CrozzleWords start = new CrozzleWords();

            //Act the methodd that will be test
            crz.ReadFile("Test 2 - MEDIUM.txt");
            List<String> wordList = new List<String>{};
            wordList=crz.getListByLength();
            start.word = wordList[wordList.Count-1];
            wordList.Remove(start.word);
            string result = newGrdy.findDiagonalWord(start.word.Length, start.word[start.word.Length-1], wordList);
            int counter = 0;
            while (result == null)
            {
                counter++;
                result = newGrdy.findDiagonalWord(start.word.Length-counter, start.word[start.word.Length - 1], wordList);
            }

            //Assert if the result is the word that expected
            Assert.IsTrue(result == "TYRIANNE");

        }

       
        /// <summary>
        /// This testing method is to test if crozzle file is validate success
        /// </summary>
        [TestMethod]
        public void TestValidateCrozzle()
        {
            //Arrang a oldCrozzle object
            oldCrozzle oldCrz = new oldCrozzle();

            //Act ValidateFile method
            string result=oldCrz.ValidateFile("Test 1 Crozzle.txt");

            //Assert if the validate result is valid(as expected)
            Assert.IsTrue(result.Contains("No error(s) detected"));

        }

        /// <summary>
        /// This testing method is to test if configuration file is validate success
        /// </summary>
        [TestMethod]
        public void TestValidateConfiguration()
        {
            //Arrang a oldConfiguration object
            oldConfiguration oldCon = new oldConfiguration();

            //Act ValidateFile method
            string result = oldCon.ValidateFile("Test 4 Configuration.txt");

            //Assert if the validate result is invalid(as expected)
            Assert.IsTrue(result.Contains("error(s) detected "));

        }
            

        }
    }

